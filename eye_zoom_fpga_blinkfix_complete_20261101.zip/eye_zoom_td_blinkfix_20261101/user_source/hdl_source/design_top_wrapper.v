

module design_top_wrapper (
    input wire        I_sys_clk,
    input wire        I_rst_n,
      
    output wire       O_cam_scl,
    inout  wire       IO_cam_sda,
    output wire       O_cam_24m,
    output wire       O_cam_rst,
      
    inout wire [1:0]  I_button,

    output wire       O_screen_pwm,

    inout wire        IO_rx_clk_pad_n, 
    inout wire        IO_rx_clk_pad_p, 
    inout wire[3:0]   IO_rx_data_pad_n,
    inout wire[3:0]   IO_rx_data_pad_p,

    inout wire        IO_tx_clk_pad_n, 
    inout wire        IO_tx_clk_pad_p, 
    inout wire[3:0]   IO_tx_data_pad_n,
    inout wire[3:0]   IO_tx_data_pad_p,

    output wire[12:0] ddr_addr,
    output wire[ 1:0] ddr_ba,
    output wire[ 0:0] ddr_cke,
    output wire[ 0:0] ddr_odt,
    output wire[ 0:0] ddr_cs_n,
    output wire       ddr_ras_n,
    output wire       ddr_cas_n,
    output wire       ddr_we_n,
    output wire[ 0:0] ddr_ck_p,
    output wire[ 0:0] ddr_ck_n,
    inout wire[1:0]   ddr_dm,
    inout wire[15:0]  ddr_dq,
    inout wire[1:0]   ddr_dqs_p,
    inout wire[1:0]   ddr_dqs_n   
);


    wire        	S_100m_clk;
    wire        	S_24m_clk;
    wire        	S_dpll_ref_clk;
	wire        	S_10m_clk;
		
	wire        	S_pll_lock;
    wire        	S_rst_n;
	
	wire [15:0] 	S_ae;
    wire [15:0] 	S_ag;
    wire 			S_cam_cfg_done;
    wire 			S_ae_cfg_done;
    wire 			S_ae_req; 
	
	wire        	S_csi_rx_clk;  
    wire        	S_hs_rx_valid;  
    wire[15:0]  	S_hs_rx_data;   
	wire[1:0]   	S_lane_error;
	
	wire        	S_csi_frame_start;       
	wire        	S_csi_frame_end;         
	wire        	S_csi_valid;             
	wire[31:0]  	S_csi_data;  
		
	wire        	S_raw10_frame_start; 
	wire        	S_raw10_frame_end;   
	wire        	S_raw10_valid;       
	wire [39:0] 	S_raw10_data;
		
	wire 			S_axis_tlast;  
	wire 			S_axis_tuser;  
	wire [39:0]		S_axis_tdata;  
	wire 			S_axis_tvalid; 
	
	wire [39:0]		S_raw_tdata ;
	wire			S_raw_tlast ;
	wire 			S_raw_tvalid;
	wire 			S_raw_tuser ;
	
	wire			S_ISP_O_tready;
	wire [127:0]	S_ISP_O_tdata ;
	wire 			S_ISP_O_tlast ;
	wire 			S_ISP_O_tuser ;
	wire 			S_ISP_O_tvalid; 
	

    wire        S_ddr_clk;
    wire        S_dsi_tx_clk;

 
    reg[31:0]   S_delay_cnt;
    wire        S_lp_config_start;


    wire        S_vi_128b_frame_start;
    wire        S_vi_128b_valid;      
    wire[127:0] S_vi_128b_data;    
    
    wire        S_video_out_rd_busy;
    wire        S_video_in_wr_busy; 
    wire[1:0]   S_video_out_rp;     

    wire        S_ddr_user_wr_en;       
    wire        S_ddr_user_rd_en;       
    wire[24:0]  S_ddr_user_addr;        
    wire[127:0] S_ddr_user_wr_data;     
    wire        S_ddr_user_ready;       
    wire        S_ddr_user_rd_valid;    
    wire[127:0] S_ddr_user_rd_data;     

    wire        S_vi_ddr_wr_en;   
    wire[24:0]  S_vi_ddr_wr_addr; 
    wire[127:0] S_vi_ddr_wr_data;
    wire        S_vi_ddr_wr_ready;

    wire        S_vo_ddr_rd_en;   
    wire[24:0]  S_vo_ddr_rd_addr; 
    wire        S_vo_ddr_rd_ready;

    wire        S_init_calib_complete; 
    wire[24:0]  S_mc_app_addr;          
    wire[2:0]   S_mc_app_cmd;           
    wire        S_mc_app_en;            
    wire[127:0] S_mc_app_wdf_data;      
    wire        S_mc_app_wdf_end;       
    wire[15:0]  S_mc_app_wdf_mask;      
    wire        S_mc_app_wdf_wren;      
    wire[127:0] S_mc_app_rd_data;       
    wire        S_mc_app_rd_data_end;   
    wire        S_mc_app_rd_data_valid; 
    wire        S_mc_app_rdy;           
    wire        S_mc_app_wdf_rdy;       

    wire        S_vs_vsync; 
    wire        S_vs_hsync; 
    wire        S_vs_de;    
    wire[23:0]  S_vs_data;  
    
    wire        S_32b_vsync; 
    wire        S_32b_hsync; 
    wire        S_32b_de;    
    wire[31:0]  S_32b_data;  

    wire        S_hs_tx_valid; 
    wire[31:0]  S_hs_tx_data;  
    wire        S_hs_tx_last;  
    wire        S_hs_tx_ready; 

    wire        S_lp_config_done;   
    wire        S_mipi_tx_dpll_locked;

    wire        S_lp_tx_p;
    wire        S_lp_tx_n;

    wire        S_vdieo_rd_en;  
    wire[23:0]  S_video_rd_data;

    wire        S_mixer_vsync;
    wire        S_mixer_hsync;
    wire        S_mixer_de;   
    wire[23:0]  S_mixer_data;

    // Eye-control pipeline and first-stage debug overlay.
    wire        S_calibration_start;
    wire[9:0]   S_eye_pixel_x;
    wire[9:0]   S_eye_pixel_y;
    wire        S_eye_roi_active;
    wire[7:0]   S_eye_gray;
    wire        S_eye_dark_candidate;
    wire[9:0]   S_pupil_x;
    wire[9:0]   S_pupil_y;
    wire[31:0]  S_eye_dark_count;
    wire[9:0]   S_debug_width, S_debug_height;
    wire        S_eye_valid;
    wire        S_closed_eye;
    wire        S_no_eye;
    wire        S_tracking_result_valid;
    wire[3:0]  S_motion_dir;
    wire[3:0]  S_last_motion_dir;
    wire signed [10:0] S_motion_dx;
    wire signed [10:0] S_motion_dy;
    wire[2:0]   S_calibration_stage;
    wire        S_calibrated;
    wire        S_calibration_failed;
    wire[2:0]   S_raw_gaze;
    wire[2:0]   S_selected_gaze;
    wire        S_nn_result_valid;
    wire[2:0]  S_nn_class;
    wire[2:0]  S_nn_selected_gaze;
    wire[7:0]   S_dwell_count;
    wire        S_selection_changed;
    wire[23:0]  S_eye_overlay_data;
    wire[23:0]  S_reader_data;
    wire[23:0]  S_display_data;
    wire        S_ms_tick;
    reg [16:0]  S_ms_div;
    wire        S_blink_event;
    wire        S_inhibit_motion;
    wire        S_motion_event_valid;
    wire[2:0]   S_motion_event_dir;
    wire        S_reader_zoomed;
    wire[9:0]   S_pan_x, S_pan_y;
    wire[15:0]  S_move_count;
    wire        S_edge_hit;
    wire        S_debug_button_pulse;
    reg         S_debug_mode;
    wire[6:0]   S_nn_debug_addr;
    wire[7:0]   S_nn_debug_gray;


    assign O_screen_pwm = 1'b1;


    always @(posedge S_10m_clk or negedge S_mipi_tx_dpll_locked) begin
        if(!S_mipi_tx_dpll_locked)
            S_delay_cnt <= 'd0;
        else
            if(S_delay_cnt >= 'd10000000)
                S_delay_cnt <= S_delay_cnt;
            else
                S_delay_cnt <= S_delay_cnt + 'd1;
    end

    assign S_lp_config_start = S_delay_cnt >= 'd200 ? 1'b1 : 1'b0;
	
	
    assign S_rst_n 		= S_pll_lock;
	
	assign O_cam_rst 	= 1'b1;
    assign O_cam_24m 	= S_24m_clk;
	
	
	
	
    PLL u_PLL(
        .refclk      ( I_sys_clk         ),
        .reset    	 ( ~I_rst_n          ),
        
        .clk0_out    ( S_100m_clk        ),
        .clk1_out    ( S_24m_clk         ),
        .clk2_out    ( S_dpll_ref_clk    ),
		.clk3_out    ( S_10m_clk         ),

        .lock        ( S_pll_lock        )

    );
	

  
  ae_set u_ae_set (
      .I_clk(S_24m_clk),
      .I_rst(~S_rst_n),
      .I_btn({1'b1,I_button[0],2'b11}),
      .I_cam_cfg_done(S_cam_cfg_done),
      .I_ae_cfg_done(S_ae_cfg_done),
      .O_ae_req(S_ae_req),
      .O_ae(S_ae),
      .O_ag(S_ag)
  );
  
    uicfgcs500 #(
      .CLK_DIV(24000000 / 100000 - 1)
  ) u_uicfgcs500 (
      .I_clk(S_24m_clk),  //系统时钟输入
      .I_rst_n(S_rst_n),  //系统复位输入
      .I_ae_req(S_ae_req),
      .I_ae(S_ae),
      .I_ag(S_ag),
      .O_cam_scl(O_cam_scl),  //I2C总线，SCL时钟
      .IO_cam_sda(IO_cam_sda),  //I2C总线，SDA数据
      .O_cfg_done(S_cam_cfg_done),  //摄像头寄存器初始化完成
      .O_ae_cfg_done(S_ae_cfg_done)  //AE配置完成
  );
	
    mipi_dphy_rx_ph1p_mipiio_wrapper#(
        .DPHY_RX_LOCATION      ( "DPHY0" ),
        .HS_EQUALIZER          ( "0dB"   ),//"0dB","1.5dB","3dB","4.5dB","6dB","7.5dB","9dB","10.5dB"
        .HS_VGA_GAIN           ( "8dB" ),//"-3dB","-1.5dB","0dB","1.5dB","3dB","4.5dB","6dB","7.5dB"
        .LANE_NUM              ( 2       ),
        .BYTE_NUM              ( 1       )
    )u_mipi_dphy_rx_ph1p_mipiio_wrapper(
        .I_lp_clk              ( S_100m_clk       ),
        .I_rst                 ( ~S_rst_n         ),

        .I_clk_lane_in_delay   ( 6'd0             ),
        .I_data_lane0_in_delay ( 6'd0             ),
        .I_data_lane1_in_delay ( 6'd0             ),
        .I_data_lane2_in_delay ( 6'd0             ),
        .I_data_lane3_in_delay ( 6'd0             ),

        .I_lane_invert         ( 4'b0000          ),
     
        .O_hs_rx_clk           ( S_csi_rx_clk     ),
        .O_hs_rx_valid         ( S_hs_rx_valid    ),
        .O_hs_rx_data          ( S_hs_rx_data     ),
      
        .O_lp_rx_lane0_p       (  ),
        .O_lp_rx_lane0_n       (  ),
      
        .I_lp_tx_en            ( 1'b0             ),
        .I_lp_tx_lane0_p       ( 1'b1             ),
        .I_lp_tx_lane0_n       ( 1'b1             ),
      
        .O_lane_match_error    (                  ),
        .O_lane_error          ( S_lane_error     ),
      
        .IO_rx_clk_pad_n       ( IO_rx_clk_pad_n  ),
        .IO_rx_clk_pad_p       ( IO_rx_clk_pad_p  ),
        .IO_rx_data_pad_n      ( IO_rx_data_pad_n ),
        .IO_rx_data_pad_p      ( IO_rx_data_pad_p )
    );
	
	
 //  cwc cwc_inst
 //(
 //    .probe0(S_hs_rx_valid),
 //    .probe1(S_hs_rx_data),
 //    .probe2(S_lane_error),
 //    .clk(S_csi_rx_clk)
 //);

 //csi 解码为RAW数据
csi_unpacket_2lane u_csi_unpacket(
.I_clk                 ( S_csi_rx_clk       ),
.I_rst_n               ( S_rst_n        	),
.I_hs_valid            ( S_hs_rx_valid     ),
.I_hs_data             ( S_hs_rx_data      ),

.O_csi_frame_start     ( S_csi_frame_start ),
.O_csi_frame_end       ( S_csi_frame_end   ),
.O_csi_valid           ( S_csi_valid       ),
.O_csi_data            ( S_csi_data        )
);


//解码为RAW8
raw10_unpacket_2lane u_raw10_unpacket (
.I_clk  (S_csi_rx_clk),
.I_rst_n(S_rst_n),

.I_csi_frame_start(S_csi_frame_start),
.I_csi_frame_end  (S_csi_frame_end),
.I_csi_valid      (S_csi_valid),
.I_csi_data       (S_csi_data),

.O_raw10_frame_start(S_raw10_frame_start),
.O_raw10_frame_end  (S_raw10_frame_end),
.O_raw10_valid      (S_raw10_valid),
.O_raw10_data       (S_raw10_data)
  );


//将数据转为stream流
uial2axis #(
.IMG_WIDTH(1920),
.IMG_HEIGHT(1080),
.INPUT_DATA_WIDTH(40)
) 
u_uial2axis (
.I_native_clk(S_csi_rx_clk),
.I_rst_n     (S_rst_n),
.I_data      (S_raw10_data       ),
.I_data_valid(S_raw10_valid      ),
.I_data_start(S_raw10_frame_start),
.I_data_end  (S_raw10_frame_end  ),
.axis_tvalid (S_axis_tvalid),
.axis_tdata  (S_axis_tdata ),
.axis_tuser  (S_axis_tuser ),
.axis_tlast  (S_axis_tlast )
);
	

image_correction #(
    .DATA_WIDTH(40)
)(
    .I_clk   		(S_csi_rx_clk),
    .I_rst_n 		(S_rst_n),
					
    .I_raw_data 	(S_axis_tdata),
    .I_raw_frame_end 	(S_axis_tlast),
    .I_raw_valid	(S_axis_tvalid),
    .I_raw_frame_start 	(S_axis_tuser),
					
    .O_raw_tdata 	(S_raw_tdata ),
    .O_raw_tlast 	(S_raw_tlast ),
    .O_raw_tvalid	(S_raw_tvalid),
    .O_raw_tuser 	(S_raw_tuser )
);


//cwc1 cwc1_Inst
//  (
//      .probe0(S_axis_tuser),
//      .probe1(S_axis_tvalid),
//      .probe2(S_axis_tlast),
//      .probe3(S_axis_tdata),
//      .probe4(S_ISP_O_tuser),
//      .probe5(S_ISP_O_tvalid),
//      .probe6(S_ISP_O_tlast),
//      .probe7(S_ISP_O_tdata),
//      .probe8 (S_raw_tdata ),
//      .probe9 (S_raw_tlast ),
//      .probe10(S_raw_tvalid),
//      .probe11(S_raw_tuser ),
//      .clk(S_csi_rx_clk)
//  );


//ISP算法顶层模块
isp_top u_isp_top (
.axi4s_video_aclk(S_csi_rx_clk),
.I_rst_n         (S_rst_n),
.I_tlast         (S_raw_tlast	),
.I_tuser         (S_raw_tuser	),
.I_tdata         (S_raw_tdata	),
.I_tvalid        (S_raw_tvalid	),
.I_tdest         (),
.O_tready        (S_ISP_O_tready),
.O_tdata         (S_ISP_O_tdata ),
.O_tlast         (S_ISP_O_tlast ),
.O_tuser         (S_ISP_O_tuser ),
.O_tvalid        (S_ISP_O_tvalid),
.I_tready        ()
  );


    video_in u_video_in(
        .I_rst_n              (  S_rst_n             ),

        .I_camera_clk         ( S_csi_rx_clk          ),
        .I_camera_frame_start ( S_ISP_O_tuser  ),
        .I_camera_valid       ( S_ISP_O_tvalid ),
        .I_camera_data        ( S_ISP_O_tdata  ),
        .I_mipi_rx_error      ( 1'b0			      ),

        .I_ddr_clk            ( S_ddr_clk             ),
		.I_display_pause      ( 1'b0                  ),
        .I_video_out_rd_busy  ( S_video_out_rd_busy   ),
        .O_video_in_wr_busy   ( S_video_in_wr_busy    ),
        .O_video_out_rp       ( S_video_out_rp        ),

        .O_ddr_user_wr_en     ( S_vi_ddr_wr_en        ),
        .O_ddr_user_addr      ( S_vi_ddr_wr_addr      ),
        .O_ddr_user_wr_data   ( S_vi_ddr_wr_data      ),
        .I_ddr_user_ready     ( S_ddr_user_ready      )
    );



    assign S_ddr_user_wr_en    = S_vi_ddr_wr_en;

    assign S_ddr_user_rd_en    = S_vo_ddr_rd_en;

    assign S_ddr_user_addr     = S_vi_ddr_wr_en ? S_vi_ddr_wr_addr :
                                 S_vo_ddr_rd_en ? S_vo_ddr_rd_addr : 'd0;

    assign S_ddr_user_wr_data  = S_vi_ddr_wr_data;


    video_out u_video_out(
        .I_rst_n             ( S_rst_n              ),
        .I_ddr_clk           ( S_ddr_clk            ),
 
        .O_video_out_rd_busy ( S_video_out_rd_busy  ),
        .I_video_in_wr_busy  ( S_video_in_wr_busy   ),
        .I_video_out_rp      ( S_video_out_rp       ),
 
        .O_ddr_user_rd_en    ( S_vo_ddr_rd_en       ),
        .O_ddr_user_addr     ( S_vo_ddr_rd_addr     ),
        .I_ddr_user_ready    ( S_ddr_user_ready     ),
        .I_ddr_user_rd_valid ( S_ddr_user_rd_valid  ),
        .I_ddr_user_rd_data  ( S_ddr_user_rd_data   ),

        .I_dsi_clk           ( S_dsi_tx_clk         ),
        .I_video_vsync       ( S_vs_vsync           ),
        .I_video_rd_en       ( S_vdieo_rd_en        ),
        .O_vdieo_data        ( S_video_rd_data      )
    );



    mc_to_user_interface u_mc_to_user_interface(
        .I_clk                   ( S_ddr_clk               ),
        .I_rst_n                 ( S_rst_n                 ),

        .I_ddr_user_wr_en        ( S_ddr_user_wr_en        ),
        .I_ddr_user_rd_en        ( S_ddr_user_rd_en        ),
        .I_ddr_user_addr         ( S_ddr_user_addr         ),
        .I_ddr_user_wr_data      ( S_ddr_user_wr_data      ),
        .O_ddr_user_ready        ( S_ddr_user_ready        ),
        .O_ddr_user_rd_valid     ( S_ddr_user_rd_valid     ),
        .O_ddr_user_rd_data      ( S_ddr_user_rd_data      ),
            
        .O_mc_app_en             ( S_mc_app_en             ),
        .O_mc_app_addr           ( S_mc_app_addr           ),
        .O_mc_app_cmd            ( S_mc_app_cmd            ),
        .I_mc_app_rdy            ( S_mc_app_rdy            ),
        .O_mc_app_wdf_wren       ( S_mc_app_wdf_wren       ),
        .O_mc_app_wdf_data       ( S_mc_app_wdf_data       ),
        .O_mc_app_wdf_end        ( S_mc_app_wdf_end        ),
        .O_mc_app_wdf_mask       ( S_mc_app_wdf_mask       ),
        .I_mc_app_wdf_rdy        ( S_mc_app_wdf_rdy        ),
        .I_mc_app_rd_data        ( S_mc_app_rd_data        ),
        .I_mc_app_rd_data_end    ( S_mc_app_rd_data_end    ),
        .I_mc_app_rd_data_valid  ( S_mc_app_rd_data_valid  )
    );



    ph1p35_324_ddr_wrapper u_ph1p35_324_ddr_wrapper(
        .I_sys_clk              ( I_sys_clk              ),
        .I_sys_rst_n            ( S_rst_n                ),

        .O_ddr_clk              ( S_ddr_clk              ),
        .O_init_calib_complete  ( S_init_calib_complete  ),
        .I_mc_app_addr          ( S_mc_app_addr          ),
        .I_mc_app_cmd           ( S_mc_app_cmd           ),
        .I_mc_app_en            ( S_mc_app_en            ),
        .I_mc_app_wdf_data      ( S_mc_app_wdf_data      ),
        .I_mc_app_wdf_end       ( S_mc_app_wdf_end       ),
        .I_mc_app_wdf_mask      ( S_mc_app_wdf_mask      ),
        .I_mc_app_wdf_wren      ( S_mc_app_wdf_wren      ),
        .O_mc_app_rd_data       ( S_mc_app_rd_data       ),
        .O_mc_app_rd_data_end   ( S_mc_app_rd_data_end   ),
        .O_mc_app_rd_data_valid ( S_mc_app_rd_data_valid ),
        .O_mc_app_rdy           ( S_mc_app_rdy           ),
        .O_mc_app_wdf_rdy       ( S_mc_app_wdf_rdy       ),

        .ddr_addr               ( ddr_addr               ),
        .ddr_ba                 ( ddr_ba                 ),
        .ddr_cke                ( ddr_cke                ),
        .ddr_odt                ( ddr_odt                ),
        .ddr_cs_n               ( ddr_cs_n               ),
        .ddr_ras_n              ( ddr_ras_n              ),
        .ddr_cas_n              ( ddr_cas_n              ),
        .ddr_we_n               ( ddr_we_n               ),
        .ddr_ck_p               ( ddr_ck_p               ),
        .ddr_ck_n               ( ddr_ck_n               ),
        .ddr_dm                 ( ddr_dm                 ),
        .ddr_dq                 ( ddr_dq                 ),
        .ddr_dqs_p              ( ddr_dqs_p              ),
        .ddr_dqs_n              ( ddr_dqs_n              )
    );



    video_source #(
        .HTOTAL ( 1344  ),
        .HSA    ( 24    ),
        .HBP    ( 136   ),
        .HFP    ( 160   ),
 
        .VTOTAL ( 635 ),
        .VSA    ( 2    ),
        .VBP    ( 21   ),
        .VFP    ( 12   )
    )u_video_source(
        .I_clk          ( S_dsi_tx_clk     ),
        .I_rst          ( ~S_rst_n         ),

        .I_config_done  ( S_lp_config_done ),

        .O_rgb24b_vsync ( S_vs_vsync       ),
        .O_rgb24b_hsync ( S_vs_hsync       ),
        .O_rgb24b_de    ( S_vs_de          ),
        .O_rgb24b_data  ( S_vs_data        )
    );


    mixer u_mixer(
        .I_clk           ( S_dsi_tx_clk    ),

        .I_video_vsync   ( S_vs_vsync      ),
        .I_video_hsync   ( S_vs_hsync      ),
        .I_video_de      ( S_vs_de         ),

        .O_vdieo_rd_en   ( S_vdieo_rd_en   ),
        .I_video_rd_data ( S_video_rd_data ),

        .O_mixer_vsync   ( S_mixer_vsync   ),
        .O_mixer_hsync   ( S_mixer_hsync   ),
        .O_mixer_de      ( S_mixer_de      ),
        .O_mixer_data    ( S_mixer_data    )
    );


    // Always-on diagnostic view: no button or calibration required.
    assign S_calibration_start = 1'b0;

    eye_control_pipeline u_eye_control_pipeline (
        .pix_clk           ( S_dsi_tx_clk         ),
        .rst_n             ( S_rst_n              ),
        .in_vsync          ( S_mixer_vsync        ),
        .in_hsync          ( S_mixer_hsync        ),
        .in_de             ( S_mixer_de           ),
        .in_rgb            ( S_mixer_data         ),
        .calibration_start ( S_calibration_start  ),
        .pixel_x           ( S_eye_pixel_x        ),
        .pixel_y           ( S_eye_pixel_y        ),
        .roi_active        ( S_eye_roi_active     ),
        .gray              ( S_eye_gray           ),
        .dark_candidate    ( S_eye_dark_candidate ),
        .pupil_x           ( S_pupil_x            ),
        .pupil_y           ( S_pupil_y            ),
        .dark_count        ( S_eye_dark_count     ),
        .debug_width       ( S_debug_width        ),
        .debug_height      ( S_debug_height       ),
        .eye_valid         ( S_eye_valid          ),
        .closed_eye        ( S_closed_eye         ),
        .no_eye            ( S_no_eye             ),
        .tracking_result_valid ( S_tracking_result_valid ),
        .calibration_stage ( S_calibration_stage  ),
        .calibrated        ( S_calibrated         ),
        .calibration_failed ( S_calibration_failed ),
        .raw_gaze          ( S_raw_gaze           ),
        .selected_gaze     ( S_selected_gaze      ),
        .dwell_count       ( S_dwell_count        ),
        .selection_changed ( S_selection_changed  )
    );

    // One millisecond at the 68.493 MHz display pixel clock.
    assign S_ms_tick=(S_ms_div==17'd68492);
    always @(posedge S_dsi_tx_clk or negedge S_rst_n) begin
        if(!S_rst_n) S_ms_div<=0;
        else if(S_ms_tick) S_ms_div<=0;
        else S_ms_div<=S_ms_div+1'b1;
    end

    reader_blink_toggle u_reader_blink_toggle (
        .clk(S_dsi_tx_clk), .rst_n(S_rst_n), .ms_tick(S_ms_tick),
        .sample_valid(S_tracking_result_valid),
        .eye_valid(S_eye_valid), .closed_eye(S_closed_eye), .no_eye(S_no_eye),
        .blink_event(S_blink_event), .inhibit_motion(S_inhibit_motion)
    );

    pupil_motion_4way u_pupil_motion_4way (
        .clk(S_dsi_tx_clk), .rst_n(S_rst_n),
        .ms_tick(S_ms_tick), .inhibit(S_inhibit_motion),
        .sample_valid(S_tracking_result_valid),
        .eye_valid(S_eye_valid), .closed_eye(S_closed_eye), .no_eye(S_no_eye),
        .pupil_x(S_pupil_x), .pupil_y(S_pupil_y),
        .motion_dir(S_motion_dir), .last_dir(S_last_motion_dir),
        .motion_event_valid(S_motion_event_valid),
        .motion_event_dir(S_motion_event_dir),
        .motion_dx(S_motion_dx), .motion_dy(S_motion_dy)
    );

    reader_pan_ctrl u_reader_pan_ctrl (
        .clk(S_dsi_tx_clk), .rst_n(S_rst_n), .frame_start(S_mixer_vsync),
        .blink_event(S_blink_event && !S_debug_mode),
        .motion_event_valid(S_motion_event_valid && !S_debug_mode &&
                            S_eye_valid && !S_closed_eye && !S_no_eye),
        .motion_event_dir(S_motion_event_dir),
        .zoomed(S_reader_zoomed), .pan_x(S_pan_x), .pan_y(S_pan_y),
        .move_count(S_move_count), .edge_hit(S_edge_hit)
    );

    // Button 1 switches between the reading page and the camera diagnostic view.
    // Button 0 retains its original camera gain control.
    button_hold_pulse #(.HOLD_CYCLES(1369860), .COUNTER_WIDTH(21))
        u_debug_button (
        .clk(S_dsi_tx_clk), .rst_n(S_rst_n), .button_n(I_button[1]),
        .pressed_pulse(S_debug_button_pulse)
    );
    always @(posedge S_dsi_tx_clk or negedge S_rst_n) begin
        if(!S_rst_n) S_debug_mode<=0;
        else if(S_debug_button_pulse) S_debug_mode<=~S_debug_mode;
    end

    reader_page u_reader_page (
        .pixel_x(S_eye_pixel_x), .pixel_y(S_eye_pixel_y), .in_de(S_mixer_de),
        .zoomed(S_reader_zoomed), .pan_x(S_pan_x), .pan_y(S_pan_y),
        .direction(S_motion_dir), .eye_valid(S_eye_valid),
        .closed_eye(S_closed_eye), .no_eye(S_no_eye),
        .move_count(S_move_count), .edge_hit(S_edge_hit), .rgb(S_reader_data)
    );
    assign S_display_data=S_debug_mode ? S_eye_overlay_data : S_reader_data;

    // EllSeg-guided compact student. The large EllSeg teacher runs only on PC;
    // this 16x8 MLP has its own fixed-point RTL inference engine on the FPGA.
    ellseg_student_mlp u_ellseg_student_mlp (
        .clk          ( S_dsi_tx_clk     ),
        .rst_n        ( S_rst_n          ),
        .in_vsync     ( S_mixer_vsync    ),
        .in_de        ( S_mixer_de       ),
        .pixel_x      ( S_eye_pixel_x   ),
        .pixel_y      ( S_eye_pixel_y   ),
        .gray         ( S_eye_gray      ),
        .result_valid ( S_nn_result_valid ),
        .class_out    ( S_nn_class      ),
        .debug_input_addr ( S_nn_debug_addr ),
        .debug_input_gray ( S_nn_debug_gray )
    );

    ellseg_student_selection u_ellseg_student_selection (
        .clk           ( S_dsi_tx_clk      ),
        .rst_n         ( S_rst_n           ),
        .result_valid  ( S_nn_result_valid ),
        .class_in      ( S_nn_class        ),
        .no_eye        ( S_no_eye         ),
        .selected_gaze ( S_nn_selected_gaze )
    );


    eye_debug_overlay u_eye_debug_overlay (
        .clk(S_dsi_tx_clk), .rst_n(S_rst_n), .in_vsync(S_mixer_vsync),
        .pixel_x(S_eye_pixel_x), .pixel_y(S_eye_pixel_y),
        .in_rgb(S_mixer_data), .pupil_x(S_pupil_x), .pupil_y(S_pupil_y),
        .eye_valid(S_eye_valid), .closed_eye(S_closed_eye), .no_eye(S_no_eye),
        .model_result_valid(S_nn_result_valid), .model_class(S_nn_class),
        .selected_gaze(S_nn_selected_gaze),
        .tracking_result_valid(S_tracking_result_valid),
        .motion_dir(S_motion_dir), .last_motion_dir(S_last_motion_dir),
        .motion_dx(S_motion_dx), .motion_dy(S_motion_dy),
        .debug_input_addr(S_nn_debug_addr), .debug_input_gray(S_nn_debug_gray),
        .debug_width(S_debug_width), .debug_height(S_debug_height),
        .out_rgb(S_eye_overlay_data)
    );

    rgb_24b_to_32b #(
       .H_ACTIVE (1024)
    )u_rgb_24b_to_32b(
        .I_clk   ( S_dsi_tx_clk      ),
        .I_rst   ( ~S_rst_n          ),

        .I_vsync ( S_mixer_vsync     ),
        .I_hsync ( S_mixer_hsync     ),
        .I_de    ( S_mixer_de        ),
        .I_data  ( S_display_data ),
                                               
        .O_vsync ( S_32b_vsync       ),
        .O_hsync ( S_32b_hsync       ),
        .O_de    ( S_32b_de          ),
        .O_data  ( S_32b_data        )
    );


    dsi_video_mode_packet #(
       .H_ACTIVE (1024)
    ) u_dsi_video_mode_packet(
        .I_clk     ( S_dsi_tx_clk  ),
        .I_rst     ( ~S_rst_n      ),
    
        .I_vsync   ( S_32b_vsync   ),
        .I_hsync   ( S_32b_hsync   ),
        .I_de      ( S_32b_de      ),
        .I_data    ( S_32b_data    ),
            
        .O_hs_en   ( S_hs_tx_valid ),
        .O_hs_data ( S_hs_tx_data  ),
        .O_hs_last ( S_hs_tx_last  )
    );



    display_config_wrapper u_display_config_wrapper(
        .I_clk          ( S_10m_clk         ),
        .I_rst          ( ~S_rst_n          ),

        .I_config_start ( S_lp_config_start ),
        .O_config_done  ( S_lp_config_done  ),

        .O_lp_tx_p      ( S_lp_tx_p         ),
        .O_lp_tx_n      ( S_lp_tx_n         )
    );


    mipi_dphy_tx_over_ph1p_mipiio_wrapper#(
        .DPHY_TX_LOCATION        ( "DPHY1"    ),
        .BYTE_NUM                ( 1          ),
        .LANE_NUM                ( 4          ),

        .CLK_LANE_MODE           ( "CONTINUE" ),
        .HS_OUTPUT_VOD           ( "200mV"    ),//"175mV","187.5mV","200mV","212.5mV","225mV","237.5mV","250mV","450mV"
        .HS_OUTPUT_IMPEDANCE     ( "50ohm"    ),//"70ohm","64ohm","58ohm","54ohm","50ohm","47ohm","44ohm","41ohm"
        .HS_OUTPUT_DE_EMPHASIS   ( "0dB"      ),//"0dB","1dB","2dB","3dB","4dB","5dB","6dB"

        .CK_OUTPUT_DELAY         ( 0  ),
        .L0_OUTPUT_DELAY         ( 0  ),
        .L1_OUTPUT_DELAY         ( 0  ),
        .L2_OUTPUT_DELAY         ( 0  ),
        .L3_OUTPUT_DELAY         ( 0  ),

        .DPLL_MULTI_RATIO        ( 20 ), //vco = 100*(20+1)=2100MHz, linerate = 1.05Gbps
        .DPLL_DIV_RATIO          ( 1  ),

        .T_DATA_LPX              ( 10 ),
        .T_DATA_HS_PREPARE       ( 10 ),
        .T_DATA_HS_ZERO          ( 20 ),
        .T_DATA_HS_TRAIL         ( 10 ),
        .T_CLK_LPX               ( 10 ),
        .T_CLK_PREPARE           ( 10 ),
        .T_CLK_ZERO              ( 10 ),
        .T_CLK_PRE               ( 10 ),
        .T_CLK_POST              ( 10 ),
        .T_CLK_TRAIL             ( 10 )
    )u_mipi_dphy_tx_over_ph1p_mipiio_wrapper(
        .I_dphy_pll_ref_clk ( S_dpll_ref_clk        ),
        .I_rst              ( ~S_rst_n              ),
        .O_dpll_locked      ( S_mipi_tx_dpll_locked ),

        .O_hs_tx_clk        ( S_dsi_tx_clk          ),
        .I_hs_tx_valid      ( S_hs_tx_valid         ),
        .I_hs_tx_data       ( S_hs_tx_data          ),
        .I_hs_tx_last       ( S_hs_tx_last          ),
        .O_hs_tx_ready      ( S_hs_tx_ready         ),

        .I_lp_tx_p          ( S_lp_tx_p             ),
        .I_lp_tx_n          ( S_lp_tx_n             ),
   
        .I_lp_rx_en         ( 1'b0                  ),
        .O_lp_rx_p          (                       ),
        .O_lp_rx_n          (                       ),
    
        .IO_tx_clk_pad_n    ( IO_tx_clk_pad_n       ),
        .IO_tx_clk_pad_p    ( IO_tx_clk_pad_p       ),
        .IO_tx_data_pad_n   ( IO_tx_data_pad_n      ),
        .IO_tx_data_pad_p   ( IO_tx_data_pad_p      )
    );


    
endmodule
