// Resource-light unsigned divider.
// One result is produced after WIDTH clock cycles; this is suitable for
// per-frame pupil centroid calculation and avoids a large combinational divider.
module unsigned_divider_seq #(
    parameter WIDTH = 32,
    parameter COUNT_WIDTH = 6
) (
    input  wire                 clk,
    input  wire                 rst_n,
    input  wire                 start,
    input  wire [WIDTH-1:0]     numerator,
    input  wire [WIDTH-1:0]     denominator,
    output reg  [WIDTH-1:0]     quotient,
    output reg                  busy,
    output reg                  done,
    output reg                  divide_by_zero
);
    reg [WIDTH:0] remainder;
    reg [WIDTH-1:0] dividend_shift;
    reg [WIDTH-1:0] quotient_work;
    reg [COUNT_WIDTH-1:0] bit_count;

    wire [WIDTH:0] shifted_remainder =
        {remainder[WIDTH-1:0], dividend_shift[WIDTH-1]};
    wire [WIDTH:0] extended_denominator = {1'b0, denominator};
    wire trial_ge_denominator = shifted_remainder >= extended_denominator;
    wire [WIDTH:0] trial_remainder = trial_ge_denominator
        ? shifted_remainder - extended_denominator
        : shifted_remainder;
    wire [WIDTH-1:0] trial_quotient =
        {quotient_work[WIDTH-2:0], trial_ge_denominator};

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            quotient       <= {WIDTH{1'b0}};
            busy           <= 1'b0;
            done           <= 1'b0;
            divide_by_zero <= 1'b0;
            remainder      <= {(WIDTH+1){1'b0}};
            dividend_shift <= {WIDTH{1'b0}};
            quotient_work  <= {WIDTH{1'b0}};
            bit_count      <= {COUNT_WIDTH{1'b0}};
        end else begin
            done <= 1'b0;
            if (start && !busy) begin
                divide_by_zero <= denominator == {WIDTH{1'b0}};
                if (denominator == {WIDTH{1'b0}}) begin
                    quotient <= {WIDTH{1'b0}};
                    busy     <= 1'b0;
                    done     <= 1'b1;
                end else begin
                    remainder      <= {(WIDTH+1){1'b0}};
                    dividend_shift <= numerator;
                    quotient_work  <= {WIDTH{1'b0}};
                    bit_count      <= WIDTH;
                    busy           <= 1'b1;
                end
            end else if (busy) begin
                remainder      <= trial_remainder;
                dividend_shift <= {dividend_shift[WIDTH-2:0], 1'b0};
                quotient_work  <= trial_quotient;
                bit_count      <= bit_count - 1'b1;
                if (bit_count == {{(COUNT_WIDTH-1){1'b0}}, 1'b1}) begin
                    quotient <= trial_quotient;
                    busy     <= 1'b0;
                    done     <= 1'b1;
                end
            end
        end
    end
endmodule
