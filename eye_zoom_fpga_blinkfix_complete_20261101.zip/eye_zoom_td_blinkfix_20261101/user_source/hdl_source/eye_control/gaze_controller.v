// FPGA-timing-friendly gaze classifier. The work is split across three pixel
// clocks (distance, nearest point, decision). Samples arrive once per video
// frame, so this adds no visible latency but avoids one long logic path.
module gaze_controller #(
    parameter DWELL_FRAMES = 15,
    parameter FILTER_SHIFT = 2
) (
    input  wire       clk,
    input  wire       rst_n,
    input  wire       sample_pulse,
    input  wire       eye_valid,
    input  wire       calibrated,
    input  wire [9:0] pupil_x,
    input  wire [9:0] pupil_y,
    input  wire [9:0] left_x,
    input  wire [9:0] left_y,
    input  wire [9:0] right_x,
    input  wire [9:0] right_y,
    input  wire [9:0] up_x,
    input  wire [9:0] up_y,
    input  wire [9:0] down_x,
    input  wire [9:0] down_y,
    input  wire [9:0] center_x,
    input  wire [9:0] center_y,
    output reg  [9:0] filtered_x,
    output reg  [9:0] filtered_y,
    output reg  [2:0] raw_gaze,
    output reg  [2:0] selected_gaze,
    output reg  [7:0] dwell_count,
    output reg        selection_changed
);
    localparam GAZE_CENTER = 3'd0;
    localparam GAZE_LEFT   = 3'd1;
    localparam GAZE_RIGHT  = 3'd2;
    localparam GAZE_UP     = 3'd3;
    localparam GAZE_DOWN   = 3'd4;

    reg filter_initialized;
    reg [2:0] candidate_gaze;
    reg [2:0] vote_1, vote_2, vote_3, vote_4;

    function [10:0] abs_diff;
        input [9:0] a;
        input [9:0] b;
        begin
            abs_diff = (a >= b) ? (a - b) : (b - a);
        end
    endfunction

    wire [10:0] horizontal_span = abs_diff(left_x, right_x);
    wire [10:0] vertical_span = abs_diff(up_y, down_y);
    reg [1:0] next_x_weight_shift, next_y_weight_shift;
    reg [1:0] x_weight_shift, y_weight_shift;

    // Power-of-two axis normalization is determined once after calibration.
    always @* begin
        next_x_weight_shift = 2'd0;
        next_y_weight_shift = 2'd0;
        if ({2'd0, horizontal_span} > ({2'd0, vertical_span} << 2))
            next_y_weight_shift = 2'd2;
        else if ({2'd0, horizontal_span} > ({2'd0, vertical_span} << 1))
            next_y_weight_shift = 2'd1;
        else if ({2'd0, vertical_span} > ({2'd0, horizontal_span} << 2))
            next_x_weight_shift = 2'd2;
        else if ({2'd0, vertical_span} > ({2'd0, horizontal_span} << 1))
            next_x_weight_shift = 2'd1;
    end

    function [13:0] scaled_abs;
        input [10:0] value;
        input [1:0] shift;
        begin
            scaled_abs = ({3'd0, value} << shift);
        end
    endfunction

    wire [14:0] distance_left_next =
        scaled_abs(abs_diff(filtered_x, left_x), x_weight_shift) +
        scaled_abs(abs_diff(filtered_y, left_y), y_weight_shift);
    wire [14:0] distance_right_next =
        scaled_abs(abs_diff(filtered_x, right_x), x_weight_shift) +
        scaled_abs(abs_diff(filtered_y, right_y), y_weight_shift);
    wire [14:0] distance_up_next =
        scaled_abs(abs_diff(filtered_x, up_x), x_weight_shift) +
        scaled_abs(abs_diff(filtered_y, up_y), y_weight_shift);
    wire [14:0] distance_down_next =
        scaled_abs(abs_diff(filtered_x, down_x), x_weight_shift) +
        scaled_abs(abs_diff(filtered_y, down_y), y_weight_shift);
    wire [14:0] distance_center_next =
        scaled_abs(abs_diff(filtered_x, center_x), x_weight_shift) +
        scaled_abs(abs_diff(filtered_y, center_y), y_weight_shift);

    reg [14:0] distance_left, distance_right, distance_up;
    reg [14:0] distance_down, distance_center;
    reg distance_valid;

    // Two-level pairwise selection instead of four chained comparisons.
    reg [14:0] horizontal_best_distance, vertical_best_distance;
    reg [2:0] horizontal_best_gaze, vertical_best_gaze;
    reg [2:0] nearest_gaze_next;
    always @* begin
        if (distance_left <= distance_right) begin
            horizontal_best_distance = distance_left;
            horizontal_best_gaze = GAZE_LEFT;
        end else begin
            horizontal_best_distance = distance_right;
            horizontal_best_gaze = GAZE_RIGHT;
        end
        if (distance_up <= distance_down) begin
            vertical_best_distance = distance_up;
            vertical_best_gaze = GAZE_UP;
        end else begin
            vertical_best_distance = distance_down;
            vertical_best_gaze = GAZE_DOWN;
        end
        nearest_gaze_next = GAZE_CENTER;
        if ((horizontal_best_distance <= vertical_best_distance) &&
            (horizontal_best_distance < distance_center))
            nearest_gaze_next = horizontal_best_gaze;
        else if ((vertical_best_distance < horizontal_best_distance) &&
                 (vertical_best_distance < distance_center))
            nearest_gaze_next = vertical_best_gaze;
    end

    reg [2:0] nearest_gaze;
    reg nearest_valid;

    wire [2:0] center_votes = {2'd0, (nearest_gaze == GAZE_CENTER)} +
                              {2'd0, (vote_1 == GAZE_CENTER)} +
                              {2'd0, (vote_2 == GAZE_CENTER)} +
                              {2'd0, (vote_3 == GAZE_CENTER)} +
                              {2'd0, (vote_4 == GAZE_CENTER)};
    wire [2:0] left_votes = {2'd0, (nearest_gaze == GAZE_LEFT)} +
                            {2'd0, (vote_1 == GAZE_LEFT)} +
                            {2'd0, (vote_2 == GAZE_LEFT)} +
                            {2'd0, (vote_3 == GAZE_LEFT)} +
                            {2'd0, (vote_4 == GAZE_LEFT)};
    wire [2:0] right_votes = {2'd0, (nearest_gaze == GAZE_RIGHT)} +
                             {2'd0, (vote_1 == GAZE_RIGHT)} +
                             {2'd0, (vote_2 == GAZE_RIGHT)} +
                             {2'd0, (vote_3 == GAZE_RIGHT)} +
                             {2'd0, (vote_4 == GAZE_RIGHT)};
    wire [2:0] up_votes = {2'd0, (nearest_gaze == GAZE_UP)} +
                          {2'd0, (vote_1 == GAZE_UP)} +
                          {2'd0, (vote_2 == GAZE_UP)} +
                          {2'd0, (vote_3 == GAZE_UP)} +
                          {2'd0, (vote_4 == GAZE_UP)};
    wire [2:0] down_votes = {2'd0, (nearest_gaze == GAZE_DOWN)} +
                            {2'd0, (vote_1 == GAZE_DOWN)} +
                            {2'd0, (vote_2 == GAZE_DOWN)} +
                            {2'd0, (vote_3 == GAZE_DOWN)} +
                            {2'd0, (vote_4 == GAZE_DOWN)};

    reg [2:0] voted_gaze;
    always @* begin
        voted_gaze = raw_gaze;
        if (center_votes >= 3) voted_gaze = GAZE_CENTER;
        else if (left_votes >= 3) voted_gaze = GAZE_LEFT;
        else if (right_votes >= 3) voted_gaze = GAZE_RIGHT;
        else if (up_votes >= 3) voted_gaze = GAZE_UP;
        else if (down_votes >= 3) voted_gaze = GAZE_DOWN;
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            filtered_x <= 10'd0;
            filtered_y <= 10'd0;
            raw_gaze <= GAZE_CENTER;
            selected_gaze <= GAZE_CENTER;
            candidate_gaze <= GAZE_CENTER;
            dwell_count <= 8'd0;
            selection_changed <= 1'b0;
            filter_initialized <= 1'b0;
            x_weight_shift <= 2'd0;
            y_weight_shift <= 2'd0;
            distance_left <= 15'd0;
            distance_right <= 15'd0;
            distance_up <= 15'd0;
            distance_down <= 15'd0;
            distance_center <= 15'd0;
            distance_valid <= 1'b0;
            nearest_gaze <= GAZE_CENTER;
            nearest_valid <= 1'b0;
            vote_1 <= GAZE_CENTER;
            vote_2 <= GAZE_CENTER;
            vote_3 <= GAZE_CENTER;
            vote_4 <= GAZE_CENTER;
        end else begin
            selection_changed <= 1'b0;

            // Stage 2: select nearest direction from registered distances.
            nearest_valid <= distance_valid;
            if (distance_valid)
                nearest_gaze <= nearest_gaze_next;
            distance_valid <= 1'b0;

            // Stage 3: vote across frames, then update the dwell decision.
            if (nearest_valid) begin
                vote_4 <= vote_3;
                vote_3 <= vote_2;
                vote_2 <= vote_1;
                vote_1 <= nearest_gaze;
                raw_gaze <= voted_gaze;
                if (voted_gaze == candidate_gaze) begin
                    if (dwell_count < DWELL_FRAMES)
                        dwell_count <= dwell_count + 1'b1;
                    if ((dwell_count + 1'b1) >= DWELL_FRAMES) begin
                        if (selected_gaze != voted_gaze) begin
                            selected_gaze <= voted_gaze;
                            selection_changed <= 1'b1;
                        end
                        dwell_count <= DWELL_FRAMES;
                    end
                end else begin
                    candidate_gaze <= voted_gaze;
                    dwell_count <= 8'd1;
                end
            end

            if (sample_pulse) begin
                if (!eye_valid || !calibrated) begin
                    dwell_count <= 8'd0;
                    candidate_gaze <= selected_gaze;
                    distance_valid <= 1'b0;
                    nearest_valid <= 1'b0;
                    if (!calibrated) begin
                        raw_gaze <= GAZE_CENTER;
                        filter_initialized <= 1'b0;
                        x_weight_shift <= 2'd0;
                        y_weight_shift <= 2'd0;
                        vote_1 <= GAZE_CENTER;
                        vote_2 <= GAZE_CENTER;
                        vote_3 <= GAZE_CENTER;
                        vote_4 <= GAZE_CENTER;
                    end
                end else if (!filter_initialized) begin
                    filtered_x <= pupil_x;
                    filtered_y <= pupil_y;
                    filter_initialized <= 1'b1;
                    x_weight_shift <= next_x_weight_shift;
                    y_weight_shift <= next_y_weight_shift;
                end else begin
                    // Stage 1: capture all normalized distances in parallel.
                    distance_left <= distance_left_next;
                    distance_right <= distance_right_next;
                    distance_up <= distance_up_next;
                    distance_down <= distance_down_next;
                    distance_center <= distance_center_next;
                    distance_valid <= 1'b1;
                    if (pupil_x >= filtered_x)
                        filtered_x <= filtered_x + ((pupil_x - filtered_x) >> FILTER_SHIFT);
                    else
                        filtered_x <= filtered_x - ((filtered_x - pupil_x) >> FILTER_SHIFT);
                    if (pupil_y >= filtered_y)
                        filtered_y <= filtered_y + ((pupil_y - filtered_y) >> FILTER_SHIFT);
                    else
                        filtered_y <= filtered_y - ((filtered_y - pupil_y) >> FILTER_SHIFT);
                end
            end
        end
    end
endmodule
