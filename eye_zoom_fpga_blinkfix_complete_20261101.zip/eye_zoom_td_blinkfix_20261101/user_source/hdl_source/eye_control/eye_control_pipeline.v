// Integrates pupil detection, five-point calibration, filtering, five-direction
// classification and 0.5-second dwell confirmation (15 frames at 30 fps).
module eye_control_pipeline (
    input  wire        pix_clk,
    input  wire        rst_n,
    input  wire        in_vsync,
    input  wire        in_hsync,
    input  wire        in_de,
    input  wire [23:0] in_rgb,
    input  wire        calibration_start,

    output wire [9:0]  pixel_x,
    output wire [9:0]  pixel_y,
    output wire        roi_active,
    output wire [7:0]  gray,
    output wire        dark_candidate,
    output wire [9:0]  pupil_x,
    output wire [9:0]  pupil_y,
    output wire [31:0] dark_count,
    output wire [9:0]  debug_width,
    output wire [9:0]  debug_height,
    output wire        eye_valid,
    output wire        closed_eye,
    output wire        no_eye,
    output wire        tracking_result_valid,
    output wire [2:0]  calibration_stage,
    output wire        calibrated,
    output wire        calibration_failed,
    output wire [2:0]  raw_gaze,
    output wire [2:0]  selected_gaze,
    output wire [7:0]  dwell_count,
    output wire        selection_changed
);
    wire result_valid;
    assign tracking_result_valid = result_valid;
    wire [9:0] left_x, left_y, right_x, right_y;
    wire [9:0] up_x, up_y, down_x, down_y, center_x, center_y;
    wire [9:0] filtered_x, filtered_y;

    eye_tracker_core u_eye_tracker_core (
        .pix_clk(pix_clk), .rst_n(rst_n),
        .in_vsync(in_vsync), .in_hsync(in_hsync), .in_de(in_de),
        .in_rgb(in_rgb), .pixel_x(pixel_x), .pixel_y(pixel_y),
        .roi_active(roi_active), .gray(gray),
        .dark_candidate(dark_candidate), .pupil_x(pupil_x),
        .pupil_y(pupil_y), .dark_count(dark_count),
        .debug_width(debug_width), .debug_height(debug_height),
        .eye_valid(eye_valid), .closed_eye(closed_eye), .no_eye(no_eye),
        .result_valid(result_valid)
    );

    five_point_calibrator u_five_point_calibrator (
        .clk(pix_clk), .rst_n(rst_n), .start(calibration_start),
        .sample_valid(result_valid && eye_valid),
        .sample_x(pupil_x), .sample_y(pupil_y),
        .stage(calibration_stage), .calibrated(calibrated),
        .calibration_failed(calibration_failed),
        .left_x(left_x), .left_y(left_y),
        .right_x(right_x), .right_y(right_y),
        .up_x(up_x), .up_y(up_y), .down_x(down_x), .down_y(down_y),
        .center_x(center_x), .center_y(center_y)
    );

    gaze_controller u_gaze_controller (
        .clk(pix_clk), .rst_n(rst_n), .sample_pulse(result_valid),
        .eye_valid(eye_valid), .calibrated(calibrated),
        .pupil_x(pupil_x), .pupil_y(pupil_y),
        .left_x(left_x), .left_y(left_y),
        .right_x(right_x), .right_y(right_y),
        .up_x(up_x), .up_y(up_y), .down_x(down_x), .down_y(down_y),
        .center_x(center_x), .center_y(center_y),
        .filtered_x(filtered_x), .filtered_y(filtered_y),
        .raw_gaze(raw_gaze), .selected_gaze(selected_gaze),
        .dwell_count(dwell_count), .selection_changed(selection_changed)
    );
endmodule
