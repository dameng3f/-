// EllSeg-guided 16x8 eye classifier student. This is NOT the EllSeg network.
// Its fixed-point weights were trained offline from team labels and EllSeg's
// pupil-coordinate guidance. One 16x8 averaged eye patch is inferred per
// display frame. Pixel ROI must be checked against the real SC500CS image.
module ellseg_student_mlp #(
    parameter ROI_X0 = 512,
    parameter ROI_Y0 = 172
) (
    input wire clk,
    input wire rst_n,
    input wire in_vsync,
    input wire in_de,
    input wire [9:0] pixel_x,
    input wire [9:0] pixel_y,
    input wire [7:0] gray,
    input wire [6:0] debug_input_addr,
    output wire [7:0] debug_input_gray,
    output reg result_valid,
    output reg [2:0] class_out
);
    localparam ST_IDLE = 3'd0;
    localparam ST_FETCH1 = 3'd1;
    localparam ST_MAC1 = 3'd2;
    localparam ST_STORE1 = 3'd3;
    localparam ST_FETCH2 = 3'd4;
    localparam ST_MAC2 = 3'd5;
    localparam ST_STORE2 = 3'd6;

    // ROMs are stored next to this HDL file; TD resolves readmemh there.
    reg signed [15:0] fc1_weight [0:4095];
    reg signed [15:0] fc1_bias   [0:31];
    reg signed [15:0] fc2_weight [0:191];
    reg signed [15:0] fc2_bias   [0:5];
    initial begin
        $readmemh("model_fc1_weight.mem", fc1_weight);
        $readmemh("model_fc1_bias.mem", fc1_bias);
        $readmemh("model_fc2_weight.mem", fc2_weight);
        $readmemh("model_fc2_bias.mem", fc2_bias);
    end

    // A 512x256 ROI is averaged to 16x8; each cell is 32x32 pixels.
    reg [17:0] column_sum [0:15];
    reg signed [15:0] input_sample [0:127];
    // Undo the exact gray-to-Q8.8 mapping for the diagnostic preview.
    wire signed [15:0] debug_q = input_sample[debug_input_addr];
    assign debug_input_gray = debug_q > 16'sd127 ? debug_q - 16'sd1 : debug_q;
    reg signed [15:0] hidden [0:31];
    reg frame_ready;
    reg vsync_d;
    wire frame_start = in_vsync && !vsync_d;
    wire roi = in_de && pixel_x >= ROI_X0 && pixel_x < ROI_X0 + 512 &&
               pixel_y >= ROI_Y0 && pixel_y < ROI_Y0 + 256;
    wire [9:0] dx = pixel_x - ROI_X0;
    wire [9:0] dy = pixel_y - ROI_Y0;
    wire [3:0] cell_x = dx[8:5];
    wire [2:0] cell_y = dy[7:5];
    wire [18:0] completed_sum = {1'b0, column_sum[cell_x]} + {11'd0, gray};
    wire [8:0] average_gray = (completed_sum + 19'd512) >> 10;
    // round(gray / 255 * 256): gray+1 exactly when gray >= 128.
    wire [9:0] input_q = {1'b0, average_gray} + {9'd0, average_gray[7]};

    integer i;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            vsync_d <= 1'b0;
            frame_ready <= 1'b0;
            for (i=0; i<16; i=i+1)
                column_sum[i] <= 18'd0;
        end else begin
            vsync_d <= in_vsync;
            if (frame_start)
                frame_ready <= 1'b0;
            if (roi) begin
                if (dy[4:0] == 5'd0 && dx[4:0] == 5'd0)
                    column_sum[cell_x] <= {10'd0, gray};
                else
                    column_sum[cell_x] <= completed_sum[17:0];
                if (dy[4:0] == 5'd31 && dx[4:0] == 5'd31)
                    input_sample[{cell_y,cell_x}] <= $signed({6'd0,input_q});
                if (dy == 10'd255 && dx == 10'd511)
                    frame_ready <= 1'b1;
            end
        end
    end

    reg [2:0] state;
    reg [5:0] output_index;
    reg [6:0] tap_index;
    reg signed [47:0] accumulator;
    reg signed [15:0] fetched_weight;
    reg signed [15:0] fetched_input;
    reg signed [15:0] best_score;
    reg [2:0] best_index;

    wire signed [47:0] rounded = (accumulator + 48'sd2048) >>> 12;
    wire signed [47:0] bias_ext_1 = {{32{fc1_bias[output_index][15]}}, fc1_bias[output_index]};
    wire signed [47:0] bias_ext_2 = {{32{fc2_bias[output_index][15]}}, fc2_bias[output_index]};
    wire signed [47:0] biased_1 = rounded + bias_ext_1;
    wire signed [47:0] biased_2 = rounded + bias_ext_2;
    wire signed [15:0] output_1 = (biased_1 < 0) ? 16'sd0 :
                                     (biased_1 > 48'sd32767) ? 16'sd32767 : biased_1[15:0];
    wire signed [15:0] output_2 = (biased_2 < -48'sd32768) ? -16'sd32768 :
                                     (biased_2 > 48'sd32767) ? 16'sd32767 : biased_2[15:0];

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state <= ST_IDLE;
            output_index <= 6'd0;
            tap_index <= 7'd0;
            accumulator <= 48'sd0;
            fetched_weight <= 16'sd0;
            fetched_input <= 16'sd0;
            best_score <= -16'sd32768;
            best_index <= 3'd0;
            result_valid <= 1'b0;
            class_out <= 3'd0;
        end else begin
            result_valid <= 1'b0;
            case (state)
                ST_IDLE: if (frame_start && frame_ready) begin
                    output_index <= 6'd0;
                    tap_index <= 7'd0;
                    accumulator <= 48'sd0;
                    best_score <= -16'sd32768;
                    best_index <= 3'd0;
                    state <= ST_FETCH1;
                end
                ST_FETCH1: begin
                    fetched_input <= input_sample[tap_index];
                    fetched_weight <= fc1_weight[{output_index[4:0],tap_index}];
                    state <= ST_MAC1;
                end
                ST_MAC1: begin
                    accumulator <= accumulator + fetched_input * fetched_weight;
                    if (tap_index == 7'd127)
                        state <= ST_STORE1;
                    else begin
                        tap_index <= tap_index + 1'b1;
                        state <= ST_FETCH1;
                    end
                end
                ST_STORE1: begin
                    hidden[output_index[4:0]] <= output_1;
                    accumulator <= 48'sd0;
                    tap_index <= 7'd0;
                    if (output_index == 6'd31) begin
                        output_index <= 6'd0;
                        state <= ST_FETCH2;
                    end else begin
                        output_index <= output_index + 1'b1;
                        state <= ST_FETCH1;
                    end
                end
                ST_FETCH2: begin
                    fetched_input <= hidden[tap_index[4:0]];
                    fetched_weight <= fc2_weight[{output_index[2:0],tap_index[4:0]}];
                    state <= ST_MAC2;
                end
                ST_MAC2: begin
                    accumulator <= accumulator + fetched_input * fetched_weight;
                    if (tap_index == 7'd31)
                        state <= ST_STORE2;
                    else begin
                        tap_index <= tap_index + 1'b1;
                        state <= ST_FETCH2;
                    end
                end
                ST_STORE2: begin
                    if (output_2 > best_score) begin
                        best_score <= output_2;
                        best_index <= output_index[2:0];
                    end
                    accumulator <= 48'sd0;
                    tap_index <= 7'd0;
                    if (output_index == 6'd5) begin
                        class_out <= (output_2 > best_score) ? output_index[2:0] : best_index;
                        result_valid <= 1'b1;
                        state <= ST_IDLE;
                    end else begin
                        output_index <= output_index + 1'b1;
                        state <= ST_FETCH2;
                    end
                end
                default: state <= ST_IDLE;
            endcase
        end
    end
endmodule

// Maps six student classes to the five reading regions. Closed/no-eye freezes
// selection. The display clock is 68.493 MHz and the frame is 1344x635 clocks,
// giving about 80.26 result pulses/second. 41 pulses gives about 0.5 seconds.
// Verify the actual cadence on the board before final timing claims.
module ellseg_student_selection #(
    parameter DWELL_SAMPLES = 41
) (
    input wire clk,
    input wire rst_n,
    input wire result_valid,
    input wire [2:0] class_in,
    input wire no_eye,
    output reg [2:0] selected_gaze
);
    reg [2:0] candidate;
    reg [7:0] count;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            selected_gaze <= 3'd0;
            candidate <= 3'd0;
            count <= 8'd0;
        end else if (result_valid) begin
            if (no_eye || class_in > 3'd4) begin
                candidate <= selected_gaze;
                count <= 8'd0;
            end else if (class_in == selected_gaze && candidate != selected_gaze) begin
                // A brief return to the current selection reduces evidence
                // instead of discarding all progress after one noisy frame.
                if (count > 8'd2)
                    count <= count - 8'd2;
                else begin
                    candidate <= selected_gaze;
                    count <= 8'd0;
                end
            end else if (class_in == candidate && candidate != selected_gaze) begin
                count <= count + 1'b1;
                if (count + 1'b1 >= DWELL_SAMPLES) begin
                    selected_gaze <= candidate;
                    count <= 8'd0;
                end
            end else if (class_in != selected_gaze && count > 8'd1) begin
                count <= count - 1'b1;
            end else if (class_in != selected_gaze) begin
                candidate <= class_in;
                count <= 8'd1;
            end
        end
    end
endmodule
