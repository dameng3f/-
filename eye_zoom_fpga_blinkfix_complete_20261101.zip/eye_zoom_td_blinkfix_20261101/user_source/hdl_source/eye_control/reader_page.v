// 1024x600 reading view. Header is 56 px; document is 1024x544 px.
// The 2x view samples a 512x272 source window, clamped by reader_pan_ctrl.
module reader_page (
    input wire [9:0] pixel_x, pixel_y,
    input wire in_de, zoomed, eye_valid, closed_eye, no_eye, edge_hit,
    input wire [9:0] pan_x, pan_y,
    input wire [3:0] direction,
    input wire [15:0] move_count,
    output reg [23:0] rgb
);
    reg [7:0] page_rom [0:2175];
    reg [15:0] font_rom [0:4095];
    initial begin
        $readmemh("reader_page.mem", page_rom);
        $readmemh("reader_font.mem", font_rom);
    end
    `include "reader_char_ids.vh"

    function [15:0] hex_code;
        input [3:0] value;
        begin
            if(value<10) hex_code=16'h0030+value;
            else hex_code=16'h0041+(value-10);
        end
    endfunction
    function [15:0] head_code;
        input [5:0] col;
        input zoom;
        input [3:0] dir;
        input valid_eye, closed, absent, at_edge;
        input [15:0] count;
        begin
            head_code=0;
            case(col)
                6'd1: head_code=16'h5b89; // 安
                6'd2: head_code=16'h8def; // 路
                6'd3: head_code=16'h773c; // 眼
                6'd4: head_code=16'h52a8; // 动
                6'd5: head_code=16'h9605; // 阅
                6'd6: head_code=16'h8bfb; // 读
                6'd10: head_code=16'h500d; // 倍
                6'd11: head_code=16'h7387; // 率
                6'd12: head_code=zoom ? 16'h0032 : 16'h0031;
                6'd13: head_code=16'h0058;
                6'd18: head_code=16'h65b9; // 方
                6'd19: head_code=16'h5411; // 向
                6'd20: begin
                    case(dir)
                        4'd1: head_code=16'h5de6; // 左
                        4'd2: head_code=16'h53f3; // 右
                        4'd3: head_code=16'h4e0a; // 上
                        4'd4: head_code=16'h4e0b; // 下
                        4'd9: head_code=16'h95ed; // 闭
                        4'd10: head_code=16'h65e0; // 无
                        default: head_code=16'h4e2d; // 中
                    endcase
                end
                6'd26: head_code=16'h773c;
                6'd27: head_code=16'h775b; // 睛
                6'd28: head_code=closed ? 16'h95ed :
                                    ((absent || !valid_eye) ? 16'h65e0 : 16'h6709);
                6'd33: head_code=16'h6b65; // 步
                6'd34: head_code=16'h6570; // 数
                6'd35: head_code=hex_code(count[15:12]);
                6'd36: head_code=hex_code(count[11:8]);
                6'd37: head_code=hex_code(count[7:4]);
                6'd38: head_code=hex_code(count[3:0]);
                6'd44: head_code=at_edge ? 16'h5230 : 0; // 到
                6'd45: head_code=at_edge ? 16'h8fb9 : 0; // 边
                6'd46: head_code=at_edge ? 16'h754c : 0; // 界
                default: head_code=0;
            endcase
        end
    endfunction

    wire doc_area=(pixel_y>=10'd56 && pixel_y<10'd600);
    wire [9:0] doc_y=pixel_y-10'd56;
    wire [9:0] src_x=zoomed ? pan_x+{1'b0,pixel_x[9:1]} : pixel_x;
    wire [9:0] src_y=zoomed ? pan_y+{1'b0,doc_y[9:1]} : doc_y;
    wire [11:0] page_addr={src_y[9:4],src_x[9:4]};
    wire [7:0] page_id=page_rom[page_addr];
    wire [15:0] page_bits=font_rom[{page_id,src_y[3:0]}];
    wire page_ink=page_bits[4'd15-src_x[3:0]];
    wire [15:0] code=head_code(pixel_x[9:4],zoomed,direction,
                                 eye_valid,closed_eye,no_eye,edge_hit,move_count);
    wire [7:0] head_id=reader_char_id(code);
    wire [15:0] head_bits=font_rom[{head_id,pixel_y[3:0]}];
    wire head_ink=(pixel_y>=10'd16 && pixel_y<10'd32) &&
                  head_bits[4'd15-pixel_x[3:0]];
    wire [10:0] px11={1'b0,pixel_x}, dx11={1'b0,doc_y};
    wire [10:0] xlo={1'b0,pan_x}, ylo={1'b0,pan_y};
    wire on_outline=!zoomed && doc_area &&
        (px11>=xlo && px11<xlo+11'd512) &&
        (dx11>=ylo && dx11<ylo+11'd272) &&
        ((px11<xlo+11'd2) || (px11>=xlo+11'd510) ||
         (dx11<ylo+11'd2) || (dx11>=ylo+11'd270));
    always @* begin
        rgb=24'h000000;
        if(in_de) begin
            if(doc_area) begin
                rgb=page_ink ? 24'h172637 : 24'hfffdf6;
                if(on_outline) rgb=24'h1673e0;
            end else if(pixel_y<10'd56) begin
                rgb=head_ink ? 24'hffffff : 24'h183b68;
                if(pixel_x>=10'd992 && pixel_x<10'd1016 &&
                   pixel_y>=10'd16 && pixel_y<10'd40)
                    rgb=eye_valid && !closed_eye && !no_eye ? 24'h41d185 : 24'he45a5a;
            end
        end
    end
endmodule
