// Streaming pupil detector for a fixed, close-up eye camera.
// Input is one RGB888 pixel per clock with DE marking the active picture.
// The module tracks dark pixels inside a fixed ROI, rejects implausible areas,
// detects a closed-eye-like horizontal shape, and calculates the centroid once
// per frame using two small iterative dividers.
module eye_tracker_core #(
    parameter FRAME_WIDTH       = 1024,
    parameter FRAME_HEIGHT      = 600,
    parameter ROI_X0            = 512,
    parameter ROI_X1            = 1023,
    // Default ROI is 512x256, so its mean uses a 17-bit shift instead of a
    // costly divider. The green debug rectangle makes physical alignment easy.
    parameter ROI_Y0            = 172,
    parameter ROI_Y1            = 427,
    parameter GRAY_THRESHOLD    = 70,
    parameter AUTO_THRESHOLD    = 1,
    parameter THRESHOLD_OFFSET  = 35,
    parameter MEDIUM_DARK_MARGIN = 24,
    parameter STRONG_DARK_MARGIN = 48,
    parameter MIN_THRESHOLD     = 20,
    parameter MAX_THRESHOLD     = 140,
    parameter MIN_DARK_PIXELS   = 80,
    parameter MAX_DARK_PIXELS   = 40000,
    parameter CLOSED_MAX_HEIGHT = 8,
    parameter CLOSED_MIN_WIDTH  = 28,
    parameter TRACK_HALF_X      = 64,
    parameter TRACK_HALF_Y      = 32,
    parameter LOCAL_MIN_PIXELS   = 50,
    parameter LOCAL_MAX_PIXELS   = 12000,
    parameter LOCAL_CLOSED_WIDTH = 64,
    parameter LOCAL_CLOSED_HEIGHT = 28
) (
    input  wire        pix_clk,
    input  wire        rst_n,
    input  wire        in_vsync,
    input  wire        in_hsync,
    input  wire        in_de,
    input  wire [23:0] in_rgb,

    output reg  [9:0]  pixel_x,
    output reg  [9:0]  pixel_y,
    output wire        roi_active,
    output wire [7:0]  gray,
    output wire        dark_candidate,

    output reg  [9:0]  pupil_x,
    output reg  [9:0]  pupil_y,
    output reg  [31:0] dark_count,
    output reg          eye_valid,
    output reg          closed_eye,
    output reg          no_eye,
    output reg          result_valid,
    output reg [9:0]    debug_width,
    output reg [9:0]    debug_height
);
    wire [7:0] red   = in_rgb[23:16];
    wire [7:0] green = in_rgb[15:8];
    wire [7:0] blue  = in_rgb[7:0];

    // 0.25R + 0.5G + 0.25B. The 10-bit sum is divided by four.
    wire [9:0] gray_sum = {2'b0, red} + ({2'b0, green} << 1) + {2'b0, blue};
    assign gray = gray_sum[9:2];

    reg vsync_d;
    reg de_d;
    wire frame_start = in_vsync && !vsync_d;
    wire line_end = !in_de && de_d;

    assign roi_active = in_de &&
                        (pixel_x >= ROI_X0) && (pixel_x <= ROI_X1) &&
                        (pixel_y >= ROI_Y0) && (pixel_y <= ROI_Y1);
    reg [7:0] active_threshold;
    assign dark_candidate = roi_active && (gray < active_threshold);

    // Pupil pixels are usually substantially darker than eyelids and skin.
    // Give successively darker pixels weights 1, 2 and 4. This divider-free
    // approximation of a dark-disk center is much less sensitive to eyelashes
    // than treating every thresholded pixel equally.
    wire medium_dark = dark_candidate &&
                       (active_threshold > MEDIUM_DARK_MARGIN) &&
                       (gray < (active_threshold - MEDIUM_DARK_MARGIN));
    wire strong_dark = dark_candidate &&
                       (active_threshold > STRONG_DARK_MARGIN) &&
                       (gray < (active_threshold - STRONG_DARK_MARGIN));
    wire [1:0] dark_weight_shift = strong_dark ? 2'd2 :
                                        medium_dark ? 2'd1 : 2'd0;
    wire [31:0] weighted_x_term = ({22'd0, pixel_x} << dark_weight_shift);
    wire [31:0] weighted_y_term = ({22'd0, pixel_y} << dark_weight_shift);
    wire [31:0] weight_term = (32'd1 << dark_weight_shift);

    reg [31:0] count_acc;
    reg [31:0] weight_acc;
    reg [31:0] sum_x_acc;
    reg [31:0] sum_y_acc;
    reg [31:0] gray_sum_acc;
    reg [9:0] min_x_acc;
    reg [9:0] max_x_acc;
    reg [9:0] min_y_acc;
    reg [9:0] max_y_acc;
    // A small window follows the most recent *accepted* pupil. Eyelid edges
    // elsewhere in the large green ROI cannot move the centroid in this mode.
    reg have_anchor;
    reg [9:0] anchor_x, anchor_y;
    reg [7:0] missing_frames;
    reg [31:0] local_count_acc, local_weight_acc;
    reg [31:0] local_sum_x_acc, local_sum_y_acc;
    reg [9:0] local_min_x, local_max_x, local_min_y, local_max_y;
    wire local_window=have_anchor &&
        ({1'b0,pixel_x}+TRACK_HALF_X >= {1'b0,anchor_x}) &&
        ({1'b0,pixel_x} <= {1'b0,anchor_x}+TRACK_HALF_X) &&
        ({1'b0,pixel_y}+TRACK_HALF_Y >= {1'b0,anchor_y}) &&
        ({1'b0,pixel_y} <= {1'b0,anchor_y}+TRACK_HALF_Y);
    wire [10:0] local_width={1'b0,local_max_x}-{1'b0,local_min_x}+1'b1;
    wire [10:0] local_height={1'b0,local_max_y}-{1'b0,local_min_y}+1'b1;
    wire local_area_plausible=(local_count_acc>=LOCAL_MIN_PIXELS) &&
                              (local_count_acc<=LOCAL_MAX_PIXELS);
    wire local_shape_closed=local_area_plausible &&
        (local_width>=LOCAL_CLOSED_WIDTH) &&
        (local_height<=LOCAL_CLOSED_HEIGHT) &&
        ({2'b0,local_width}>=({2'b0,local_height}<<2));
    wire accepted_area=have_anchor ? local_area_plausible : area_plausible;
    wire accepted_closed=have_anchor ? local_shape_closed : shape_closed;

    reg [31:0] snapshot_count;
    reg [31:0] snapshot_sum_x;
    reg [31:0] snapshot_sum_y;
    reg centroid_start;
    reg pending_valid;

    wire [10:0] candidate_width = {1'b0, max_x_acc} - {1'b0, min_x_acc} + 1'b1;
    wire [10:0] candidate_height = {1'b0, max_y_acc} - {1'b0, min_y_acc} + 1'b1;
    wire area_plausible = (count_acc >= MIN_DARK_PIXELS) &&
                          (count_acc <= MAX_DARK_PIXELS);
    wire shape_closed = area_plausible &&
                        (candidate_height <= CLOSED_MAX_HEIGHT) &&
                        (candidate_width >= CLOSED_MIN_WIDTH);
    wire [31:0] roi_mean_full = gray_sum_acc >> 17;
    wire [7:0] roi_mean = roi_mean_full[7:0];
    wire [7:0] threshold_minus_offset = (roi_mean > THRESHOLD_OFFSET)
        ? roi_mean - THRESHOLD_OFFSET : 8'd0;
    wire [7:0] next_threshold =
        (threshold_minus_offset < MIN_THRESHOLD) ? MIN_THRESHOLD :
        (threshold_minus_offset > MAX_THRESHOLD) ? MAX_THRESHOLD :
        threshold_minus_offset;

    wire [31:0] quotient_x;
    wire [31:0] quotient_y;
    wire divider_x_done;
    wire divider_y_done;

    unsigned_divider_seq #(.WIDTH(32), .COUNT_WIDTH(6)) u_divider_x (
        .clk(pix_clk), .rst_n(rst_n), .start(centroid_start),
        .numerator(snapshot_sum_x), .denominator(snapshot_count),
        .quotient(quotient_x), .busy(), .done(divider_x_done),
        .divide_by_zero()
    );

    unsigned_divider_seq #(.WIDTH(32), .COUNT_WIDTH(6)) u_divider_y (
        .clk(pix_clk), .rst_n(rst_n), .start(centroid_start),
        .numerator(snapshot_sum_y), .denominator(snapshot_count),
        .quotient(quotient_y), .busy(), .done(divider_y_done),
        .divide_by_zero()
    );

    // Generate active-picture coordinates from DE. HSYNC is retained in the
    // interface because the vendor design supplies it, but DE edges define rows.
    always @(posedge pix_clk or negedge rst_n) begin
        if (!rst_n) begin
            vsync_d <= 1'b0;
            de_d    <= 1'b0;
            pixel_x <= 10'd0;
            pixel_y <= 10'd0;
        end else begin
            vsync_d <= in_vsync;
            de_d    <= in_de;
            if (frame_start) begin
                pixel_x <= 10'd0;
                pixel_y <= 10'd0;
            end else if (in_de) begin
                pixel_x <= pixel_x + 1'b1;
            end else if (line_end) begin
                pixel_x <= 10'd0;
                pixel_y <= pixel_y + 1'b1;
            end
        end
    end

    always @(posedge pix_clk or negedge rst_n) begin
        if (!rst_n) begin
            count_acc      <= 32'd0;
            weight_acc     <= 32'd0;
            sum_x_acc      <= 32'd0;
            sum_y_acc      <= 32'd0;
            gray_sum_acc   <= 32'd0;
            min_x_acc      <= 10'h3ff;
            max_x_acc      <= 10'd0;
            min_y_acc      <= 10'h3ff;
            max_y_acc      <= 10'd0;
            have_anchor    <= 1'b0;
            anchor_x       <= 10'd0;
            anchor_y       <= 10'd0;
            missing_frames <= 8'd0;
            local_count_acc <= 32'd0;
            local_weight_acc <= 32'd0;
            local_sum_x_acc <= 32'd0;
            local_sum_y_acc <= 32'd0;
            local_min_x <= 10'h3ff;
            local_max_x <= 10'd0;
            local_min_y <= 10'h3ff;
            local_max_y <= 10'd0;
            snapshot_count <= 32'd0;
            snapshot_sum_x <= 32'd0;
            snapshot_sum_y <= 32'd0;
            centroid_start <= 1'b0;
            pending_valid  <= 1'b0;
            pupil_x        <= 10'd0;
            pupil_y        <= 10'd0;
            dark_count     <= 32'd0;
            eye_valid      <= 1'b0;
            closed_eye     <= 1'b0;
            no_eye         <= 1'b1;
            result_valid   <= 1'b0;
            debug_width    <= 10'd0;
            debug_height   <= 10'd0;
            active_threshold <= GRAY_THRESHOLD;
        end else begin
            centroid_start <= 1'b0;
            result_valid   <= 1'b0;

            if (frame_start) begin
                dark_count <= count_acc;
                closed_eye <= accepted_closed;
                no_eye     <= !accepted_area;
                debug_width <= have_anchor ?
                    (local_count_acc!=0 ? local_width[9:0] : 10'd0) :
                    (count_acc!=0 ? candidate_width[9:0] : 10'd0);
                debug_height <= have_anchor ?
                    (local_count_acc!=0 ? local_height[9:0] : 10'd0) :
                    (count_acc!=0 ? candidate_height[9:0] : 10'd0);

                if (accepted_area && !accepted_closed) begin
                    snapshot_count <= have_anchor ? local_weight_acc : weight_acc;
                    snapshot_sum_x <= have_anchor ? local_sum_x_acc : sum_x_acc;
                    snapshot_sum_y <= have_anchor ? local_sum_y_acc : sum_y_acc;
                    centroid_start <= 1'b1;
                    pending_valid  <= 1'b1;
                    missing_frames <= 0;
                end else begin
                    eye_valid     <= 1'b0;
                    pending_valid <= 1'b0;
                    result_valid  <= 1'b1;
                    if(accepted_closed) missing_frames<=0;
                    else if(missing_frames<8'd120) missing_frames<=missing_frames+1'b1;
                    else have_anchor<=1'b0;
                end

                count_acc <= 32'd0;
                weight_acc <= 32'd0;
                sum_x_acc <= 32'd0;
                sum_y_acc <= 32'd0;
                gray_sum_acc <= 32'd0;
                if (AUTO_THRESHOLD)
                    active_threshold <= next_threshold;
                min_x_acc <= 10'h3ff;
                max_x_acc <= 10'd0;
                min_y_acc <= 10'h3ff;
                max_y_acc <= 10'd0;
                local_count_acc <= 32'd0;
                local_weight_acc <= 32'd0;
                local_sum_x_acc <= 32'd0;
                local_sum_y_acc <= 32'd0;
                local_min_x <= 10'h3ff;
                local_max_x <= 10'd0;
                local_min_y <= 10'h3ff;
                local_max_y <= 10'd0;
            end else begin
                if (roi_active)
                    gray_sum_acc <= gray_sum_acc + gray;
                if (dark_candidate) begin
                    count_acc <= count_acc + 1'b1;
                    weight_acc <= weight_acc + weight_term;
                    sum_x_acc <= sum_x_acc + weighted_x_term;
                    sum_y_acc <= sum_y_acc + weighted_y_term;
                    if (pixel_x < min_x_acc) min_x_acc <= pixel_x;
                    if (pixel_x > max_x_acc) max_x_acc <= pixel_x;
                    if (pixel_y < min_y_acc) min_y_acc <= pixel_y;
                    if (pixel_y > max_y_acc) max_y_acc <= pixel_y;
                    if (local_window) begin
                        local_count_acc <= local_count_acc + 1'b1;
                        local_weight_acc <= local_weight_acc + weight_term;
                        local_sum_x_acc <= local_sum_x_acc + weighted_x_term;
                        local_sum_y_acc <= local_sum_y_acc + weighted_y_term;
                        if(pixel_x<local_min_x) local_min_x<=pixel_x;
                        if(pixel_x>local_max_x) local_max_x<=pixel_x;
                        if(pixel_y<local_min_y) local_min_y<=pixel_y;
                        if(pixel_y>local_max_y) local_max_y<=pixel_y;
                    end
                end
            end

            if (divider_x_done && divider_y_done && pending_valid) begin
                pupil_x      <= quotient_x[9:0];
                pupil_y      <= quotient_y[9:0];
                anchor_x     <= quotient_x[9:0];
                anchor_y     <= quotient_y[9:0];
                have_anchor  <= 1'b1;
                eye_valid    <= 1'b1;
                no_eye       <= 1'b0;
                closed_eye   <= 1'b0;
                result_valid <= 1'b1;
                pending_valid <= 1'b0;
            end
        end
    end

    // Prevent an unused-input warning without changing the data path.
    wire unused_hsync = in_hsync;
endmodule
