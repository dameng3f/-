// Automatic five-point calibration controller.
// Stage order shown by the UI must be LEFT, RIGHT, UP, DOWN, CENTER.
// Only valid-eye samples advance the sequence. At 30 fps the defaults take
// about 10 seconds: 45 settle frames + 16 averaged frames per point.
module five_point_calibrator #(
    parameter SETTLE_SAMPLES  = 45,
    parameter CAPTURE_SAMPLES = 16,
    parameter CAPTURE_SHIFT   = 4,
    parameter MIN_HORIZONTAL_SPAN = 12,
    parameter MIN_VERTICAL_SPAN   = 8
) (
    input  wire       clk,
    input  wire       rst_n,
    input  wire       start,
    input  wire       sample_valid,
    input  wire [9:0] sample_x,
    input  wire [9:0] sample_y,

    output reg  [2:0] stage,
    output reg        calibrated,
    output reg        calibration_failed,
    output reg  [9:0] left_x,
    output reg  [9:0] left_y,
    output reg  [9:0] right_x,
    output reg  [9:0] right_y,
    output reg  [9:0] up_x,
    output reg  [9:0] up_y,
    output reg  [9:0] down_x,
    output reg  [9:0] down_y,
    output reg  [9:0] center_x,
    output reg  [9:0] center_y
);
    localparam ST_IDLE   = 3'd0;
    localparam ST_LEFT   = 3'd1;
    localparam ST_RIGHT  = 3'd2;
    localparam ST_UP     = 3'd3;
    localparam ST_DOWN   = 3'd4;
    localparam ST_CENTER = 3'd5;
    localparam ST_DONE   = 3'd6;
    localparam ST_FAILED = 3'd7;

    reg [7:0] settle_count;
    reg [7:0] capture_count;
    reg [23:0] sum_x;
    reg [23:0] sum_y;

    wire [23:0] completed_sum_x = sum_x + sample_x;
    wire [23:0] completed_sum_y = sum_y + sample_y;
    wire [9:0] average_x = completed_sum_x >> CAPTURE_SHIFT;
    wire [9:0] average_y = completed_sum_y >> CAPTURE_SHIFT;

    function [10:0] abs_diff;
        input [9:0] a;
        input [9:0] b;
        begin
            abs_diff = (a >= b) ? (a - b) : (b - a);
        end
    endfunction

    wire [10:0] horizontal_span = abs_diff(left_x, right_x);
    wire [10:0] vertical_span = abs_diff(up_y, down_y);
    wire calibration_spans_valid =
        (horizontal_span >= MIN_HORIZONTAL_SPAN) &&
        (vertical_span >= MIN_VERTICAL_SPAN);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            stage         <= ST_IDLE;
            calibrated    <= 1'b0;
            calibration_failed <= 1'b0;
            settle_count  <= 8'd0;
            capture_count <= 8'd0;
            sum_x          <= 24'd0;
            sum_y          <= 24'd0;
            left_x         <= 10'd0;
            left_y         <= 10'd0;
            right_x        <= 10'd0;
            right_y        <= 10'd0;
            up_x           <= 10'd0;
            up_y           <= 10'd0;
            down_x         <= 10'd0;
            down_y         <= 10'd0;
            center_x       <= 10'd0;
            center_y       <= 10'd0;
        end else begin
            if (start) begin
                stage         <= ST_LEFT;
                calibrated    <= 1'b0;
                calibration_failed <= 1'b0;
                settle_count  <= 8'd0;
                capture_count <= 8'd0;
                sum_x          <= 24'd0;
                sum_y          <= 24'd0;
            end else if ((stage >= ST_LEFT) && (stage <= ST_CENTER) && sample_valid) begin
                if (settle_count < SETTLE_SAMPLES) begin
                    settle_count <= settle_count + 1'b1;
                end else if (capture_count == CAPTURE_SAMPLES - 1) begin
                    case (stage)
                        ST_LEFT: begin
                            left_x <= average_x;
                            left_y <= average_y;
                        end
                        ST_RIGHT: begin
                            right_x <= average_x;
                            right_y <= average_y;
                        end
                        ST_UP: begin
                            up_x <= average_x;
                            up_y <= average_y;
                        end
                        ST_DOWN: begin
                            down_x <= average_x;
                            down_y <= average_y;
                        end
                        ST_CENTER: begin
                            center_x <= average_x;
                            center_y <= average_y;
                        end
                        default: begin
                            // The surrounding stage check prevents this path.
                        end
                    endcase
                    settle_count  <= 8'd0;
                    capture_count <= 8'd0;
                    sum_x          <= 24'd0;
                    sum_y          <= 24'd0;
                    if (stage == ST_CENTER) begin
                        if (calibration_spans_valid) begin
                            stage      <= ST_DONE;
                            calibrated <= 1'b1;
                            calibration_failed <= 1'b0;
                        end else begin
                            stage      <= ST_FAILED;
                            calibrated <= 1'b0;
                            calibration_failed <= 1'b1;
                        end
                    end else begin
                        stage <= stage + 1'b1;
                    end
                end else begin
                    capture_count <= capture_count + 1'b1;
                    sum_x <= completed_sum_x;
                    sum_y <= completed_sum_y;
                end
            end
        end
    end
endmodule
