// Five-zone fixed reading page.  All text is pre-rendered from a small font ROM.
// The selected phrase is redrawn at 2x size in a dedicated magnification panel.
module reading_ui (
    input  wire [9:0]  pixel_x,
    input  wire [9:0]  pixel_y,
    input  wire [23:0] camera_rgb,
    input  wire        reading_mode,
    input  wire [2:0]  selected_gaze,
    input  wire        eye_valid,
    output reg  [23:0] out_rgb
);
    localparam GAZE_CENTER = 3'd0;
    localparam GAZE_LEFT   = 3'd1;
    localparam GAZE_RIGHT  = 3'd2;
    localparam GAZE_UP     = 3'd3;
    localparam GAZE_DOWN   = 3'd4;

    // Generated font indexes:
    // 1左 2侧 3文 4字 5右 6上 7方 8下 9中 10心
    function [4:0] phrase_char;
        input [2:0] gaze;
        input [1:0] position;
        begin
            case (gaze)
                GAZE_LEFT: begin
                    case (position)
                        2'd0: phrase_char = 5'd1;
                        2'd1: phrase_char = 5'd2;
                        2'd2: phrase_char = 5'd3;
                        default: phrase_char = 5'd4;
                    endcase
                end
                GAZE_RIGHT: begin
                    case (position)
                        2'd0: phrase_char = 5'd5;
                        2'd1: phrase_char = 5'd2;
                        2'd2: phrase_char = 5'd3;
                        default: phrase_char = 5'd4;
                    endcase
                end
                GAZE_UP: begin
                    case (position)
                        2'd0: phrase_char = 5'd6;
                        2'd1: phrase_char = 5'd7;
                        2'd2: phrase_char = 5'd3;
                        default: phrase_char = 5'd4;
                    endcase
                end
                GAZE_DOWN: begin
                    case (position)
                        2'd0: phrase_char = 5'd8;
                        2'd1: phrase_char = 5'd7;
                        2'd2: phrase_char = 5'd3;
                        default: phrase_char = 5'd4;
                    endcase
                end
                default: begin
                    case (position)
                        2'd0: phrase_char = 5'd9;
                        2'd1: phrase_char = 5'd10;
                        2'd2: phrase_char = 5'd3;
                        default: phrase_char = 5'd4;
                    endcase
                end
            endcase
        end
    endfunction

    reg normal_active;
    reg [4:0] normal_char;
    reg [3:0] normal_x;
    reg [3:0] normal_y;
    reg [1:0] normal_position;
    reg [2:0] normal_gaze;
    reg [9:0] base_x;
    reg [9:0] base_y;

    always @* begin
        normal_active = 1'b0;
        normal_char = 5'd0;
        normal_x = 4'd0;
        normal_y = 4'd0;
        normal_position = 2'd0;
        normal_gaze = GAZE_CENTER;
        base_x = 10'd0;
        base_y = 10'd0;

        if ((pixel_x >= 10'd40) && (pixel_x < 10'd104) &&
            (pixel_y >= 10'd292) && (pixel_y < 10'd308)) begin
            normal_active = 1'b1; normal_gaze = GAZE_LEFT;
            base_x = 10'd40; base_y = 10'd292;
        end else if ((pixel_x >= 10'd920) && (pixel_x < 10'd984) &&
                     (pixel_y >= 10'd292) && (pixel_y < 10'd308)) begin
            normal_active = 1'b1; normal_gaze = GAZE_RIGHT;
            base_x = 10'd920; base_y = 10'd292;
        end else if ((pixel_x >= 10'd480) && (pixel_x < 10'd544) &&
                     (pixel_y >= 10'd72) && (pixel_y < 10'd88)) begin
            normal_active = 1'b1; normal_gaze = GAZE_UP;
            base_x = 10'd480; base_y = 10'd72;
        end else if ((pixel_x >= 10'd480) && (pixel_x < 10'd544) &&
                     (pixel_y >= 10'd512) && (pixel_y < 10'd528)) begin
            normal_active = 1'b1; normal_gaze = GAZE_DOWN;
            base_x = 10'd480; base_y = 10'd512;
        end else if ((pixel_x >= 10'd480) && (pixel_x < 10'd544) &&
                     (pixel_y >= 10'd252) && (pixel_y < 10'd268)) begin
            normal_active = 1'b1; normal_gaze = GAZE_CENTER;
            base_x = 10'd480; base_y = 10'd252;
        end

        if (normal_active) begin
            normal_position = (pixel_x - base_x) >> 4;
            normal_char = phrase_char(normal_gaze, normal_position);
            normal_x = pixel_x - base_x;
            normal_y = pixel_y - base_y;
        end
    end

    wire [15:0] normal_row_bits;
    font16_rom u_normal_font (
        .char_index(normal_char), .row(normal_y), .bits(normal_row_bits)
    );
    wire normal_pixel = normal_active && normal_row_bits[15 - normal_x];

    wire magnify_panel = (pixel_x >= 10'd432) && (pixel_x < 10'd592) &&
                         (pixel_y >= 10'd380) && (pixel_y < 10'd436);
    wire magnify_active = (pixel_x >= 10'd448) && (pixel_x < 10'd576) &&
                          (pixel_y >= 10'd392) && (pixel_y < 10'd424);
    wire [6:0] magnify_rel_x = pixel_x - 10'd448;
    wire [5:0] magnify_rel_y = pixel_y - 10'd392;
    wire [1:0] magnify_position = magnify_rel_x >> 5;
    wire [3:0] magnify_x = magnify_rel_x[4:1];
    wire [3:0] magnify_y = magnify_rel_y[4:1];
    wire [4:0] magnify_char = phrase_char(selected_gaze, magnify_position);
    wire [15:0] magnify_row_bits;
    font16_rom u_magnify_font (
        .char_index(magnify_char), .row(magnify_y), .bits(magnify_row_bits)
    );
    wire magnify_pixel = magnify_active && magnify_row_bits[15 - magnify_x];

    wire status_lamp = (pixel_x >= 10'd16) && (pixel_x < 10'd48) &&
                       (pixel_y >= 10'd16) && (pixel_y < 10'd48);

    always @* begin
        if (!reading_mode) begin
            out_rgb = camera_rgb;
        end else begin
            out_rgb = 24'hF6F4EC;
            if (magnify_panel)
                out_rgb = 24'hDDEBFF;
            if (normal_pixel)
                out_rgb = 24'h202020;
            if (magnify_pixel)
                out_rgb = 24'h0050C8;
            if (status_lamp)
                out_rgb = eye_valid ? 24'h00B050 : 24'hD02020;
        end
    end
endmodule
