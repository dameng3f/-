// Reading controls use the existing pupil centroid and eye status.
// All times come from a 1 ms tick in the display clock domain.
module pupil_motion_4way #(
    parameter [10:0] MOVE_PX = 11'd8,
    parameter [9:0] CONFIRM_MS = 10'd100,
    parameter [9:0] MIN_INTERVAL_MS = 10'd500
) (
    input wire clk, rst_n, ms_tick, sample_valid, inhibit,
    input wire eye_valid, closed_eye, no_eye,
    input wire [9:0] pupil_x, pupil_y,
    output reg [3:0] motion_dir, last_dir,
    output reg motion_event_valid,
    output reg [2:0] motion_event_dir,
    output reg signed [10:0] motion_dx, motion_dy
);
    reg anchored;
    reg [9:0] smooth_x, smooth_y, anchor_x, anchor_y;
    reg [2:0] candidate;
    reg [1:0] candidate_samples;
    reg [9:0] candidate_ms, cooldown_ms, display_ms;
    wire [11:0] sx_sum=({2'b0,smooth_x}<<1)+{2'b0,smooth_x}+{2'b0,pupil_x}+12'd2;
    wire [11:0] sy_sum=({2'b0,smooth_y}<<1)+{2'b0,smooth_y}+{2'b0,pupil_y}+12'd2;
    wire [9:0] nx=sx_sum[11:2], ny=sy_sum[11:2];
    wire signed [10:0] dx=$signed({1'b0,nx})-$signed({1'b0,anchor_x});
    wire signed [10:0] dy=$signed({1'b0,ny})-$signed({1'b0,anchor_y});
    wire xneg=nx<anchor_x, yneg=ny<anchor_y;
    wire [10:0] ax=xneg ? ({1'b0,anchor_x}-{1'b0,nx}) : ({1'b0,nx}-{1'b0,anchor_x});
    wire [10:0] ay=yneg ? ({1'b0,anchor_y}-{1'b0,ny}) : ({1'b0,ny}-{1'b0,anchor_y});
    wire major_x=({2'b0,ax}>({2'b0,ay}+({2'b0,ay}>>2)));
    wire major_y=({2'b0,ay}>({2'b0,ax}+({2'b0,ax}>>2)));
    wire [2:0] observed=major_x ? (xneg ? 3'd1 : 3'd2) :
                        major_y ? (yneg ? 3'd3 : 3'd4) : 3'd0;
    wire qualified=(ax>=MOVE_PX || ay>=MOVE_PX) && observed!=0;
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            anchored<=0; smooth_x<=0; smooth_y<=0; anchor_x<=0; anchor_y<=0;
            candidate<=0; candidate_samples<=0; candidate_ms<=0;
            cooldown_ms<=0; display_ms<=0;
            motion_dir<=4'd10; last_dir<=0; motion_event_valid<=0;
            motion_event_dir<=0; motion_dx<=0; motion_dy<=0;
        end else begin
            motion_event_valid<=0;
            if(ms_tick) begin
                if(cooldown_ms!=0) cooldown_ms<=cooldown_ms-1'b1;
                if(display_ms!=0) begin
                    display_ms<=display_ms-1'b1;
                    if(display_ms==1) motion_dir<=0;
                end
                if(candidate!=0 && candidate_ms<CONFIRM_MS)
                    candidate_ms<=candidate_ms+1'b1;
            end
            if(sample_valid) begin
                if(inhibit || !eye_valid || closed_eye || no_eye) begin
                    anchored<=0; candidate<=0; candidate_samples<=0; candidate_ms<=0;
                    display_ms<=0;
                    motion_dir<=closed_eye ? 4'd9 :
                                ((!eye_valid || no_eye) ? 4'd10 : 4'd0);
                    last_dir<=0;
                    motion_dx<=0; motion_dy<=0;
                end else if(!anchored) begin
                    anchored<=1; smooth_x<=pupil_x; smooth_y<=pupil_y;
                    anchor_x<=pupil_x; anchor_y<=pupil_y;
                    candidate<=0; candidate_samples<=0; candidate_ms<=0;
                    motion_dir<=0; motion_dx<=0; motion_dy<=0;
                end else begin
                    smooth_x<=nx; smooth_y<=ny; motion_dx<=dx; motion_dy<=dy;
                    if(!qualified) begin
                        candidate<=0; candidate_samples<=0; candidate_ms<=0;
                    end else if(observed!=candidate) begin
                        candidate<=observed; candidate_samples<=2'd1; candidate_ms<=0;
                    end else if(candidate_samples>=2 && candidate_ms>=CONFIRM_MS && cooldown_ms==0) begin
                        motion_event_valid<=1;
                        motion_event_dir<=observed;
                        motion_dir<={1'b0,observed}; last_dir<={1'b0,observed};
                        anchor_x<=nx; anchor_y<=ny;
                        candidate<=0; candidate_samples<=0; candidate_ms<=0;
                        cooldown_ms<=MIN_INTERVAL_MS;
                        display_ms<=10'd500;
                    end else if(candidate_samples<2) begin
                        candidate_samples<=candidate_samples+1'b1;
                    end
                end
            end
        end
    end
endmodule

// One deliberate blink toggles zoom after the eye has reopened.
// A brief NO_EYE gap can represent an eyelid occlusion; long gaps abort.
module reader_blink_toggle #(
    parameter [9:0] MIN_CLOSED_MS=10'd250,
    parameter [9:0] MAX_CLOSED_MS=10'd800
) (
    input wire clk, rst_n, ms_tick, sample_valid,
    input wire eye_valid, closed_eye, no_eye,
    output reg blink_event,
    output wire inhibit_motion
);
    localparam WAIT_OPEN=3'd0, ARMED=3'd1, CLOSED=3'd2,
               REOPEN=3'd3, COOLDOWN=3'd4;
    reg [2:0] state;
    reg [9:0] elapsed_ms;
    wire open_now=eye_valid && !closed_eye && !no_eye;
    assign inhibit_motion=(state!=ARMED);
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin state<=WAIT_OPEN; elapsed_ms<=0; blink_event<=0; end
        else begin
            blink_event<=0;
            if(ms_tick && elapsed_ms<10'd1000) elapsed_ms<=elapsed_ms+1'b1;
            if(sample_valid) begin
                case(state)
                    WAIT_OPEN: if(!open_now) elapsed_ms<=0;
                               else if(elapsed_ms>=10'd100) begin state<=ARMED; elapsed_ms<=0; end
                    ARMED: if(!open_now) begin state<=CLOSED; elapsed_ms<=0; end
                    CLOSED: if(elapsed_ms>MAX_CLOSED_MS) begin state<=WAIT_OPEN; elapsed_ms<=0; end
                            else if(open_now) begin
                                if(elapsed_ms>=MIN_CLOSED_MS) begin state<=REOPEN; elapsed_ms<=0; end
                                else begin state<=WAIT_OPEN; elapsed_ms<=0; end
                            end
                    REOPEN: if(!open_now) begin state<=WAIT_OPEN; elapsed_ms<=0; end
                            else if(elapsed_ms>=10'd60) begin
                                blink_event<=1; state<=COOLDOWN; elapsed_ms<=0;
                            end
                    COOLDOWN: if(elapsed_ms>=10'd500) begin state<=WAIT_OPEN; elapsed_ms<=0; end
                    default: begin state<=WAIT_OPEN; elapsed_ms<=0; end
                endcase
            end
        end
    end
endmodule

module reader_pan_ctrl (
    input wire clk, rst_n, frame_start, blink_event,
    input wire motion_event_valid,
    input wire [2:0] motion_event_dir,
    output reg zoomed,
    output reg [9:0] pan_x, pan_y,
    output reg [15:0] move_count,
    output reg edge_hit
);
    reg zoom_next;
    reg [9:0] x_next,y_next;
    reg [15:0] count_next;
    reg edge_next;
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            zoom_next<=0; x_next<=10'd256; y_next<=10'd128;
            count_next<=0; edge_next<=0;
            zoomed<=0; pan_x<=10'd256; pan_y<=10'd128;
            move_count<=0; edge_hit<=0;
        end else begin
            if(blink_event) zoom_next<=~zoom_next;
            if(motion_event_valid) begin
                count_next<=count_next+1'b1;
                edge_next<=0;
                case(motion_event_dir)
                    3'd1: if(x_next>=10'd32) x_next<=x_next-10'd32;
                          else begin x_next<=0; edge_next<=1; end
                    3'd2: if(x_next<=10'd480) x_next<=x_next+10'd32;
                          else begin x_next<=10'd512; edge_next<=1; end
                    3'd3: if(y_next>=10'd32) y_next<=y_next-10'd32;
                          else begin y_next<=0; edge_next<=1; end
                    3'd4: if(y_next<=10'd240) y_next<=y_next+10'd32;
                          else begin y_next<=10'd272; edge_next<=1; end
                    default: edge_next<=0;
                endcase
            end
            if(frame_start) begin
                zoomed<=zoom_next; pan_x<=x_next; pan_y<=y_next;
                move_count<=count_next; edge_hit<=edge_next;
            end
        end
    end
endmodule
