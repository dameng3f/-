// Eight-way motion events from the existing pupil tracker. This reports
// movement, not the location at which the user is currently looking.
module pupil_motion_8way #(
    parameter [10:0] MOVE_THRESHOLD = 11'd8,
    parameter [7:0] DISPLAY_SAMPLES = 8'd40
) (
    input wire clk,
    input wire rst_n,
    input wire sample_valid,
    input wire eye_valid,
    input wire closed_eye,
    input wire no_eye,
    input wire [9:0] pupil_x,
    input wire [9:0] pupil_y,
    output reg [3:0] motion_dir,
    output reg [3:0] last_dir,
    output reg signed [10:0] motion_dx,
    output reg signed [10:0] motion_dy
);
    // Codes: 0 still, 1 left, 2 right, 3 up, 4 down,
    // 5 upper-left, 6 upper-right, 7 lower-left, 8 lower-right,
    // 9 closed, 10 no eye.
    reg anchored;
    reg [9:0] smooth_x, smooth_y, anchor_x, anchor_y;
    reg [3:0] candidate;
    reg [1:0] candidate_count;
    reg [7:0] display_count;

    // A 3:1 running average suppresses single-frame centroid jitter.
    wire [11:0] sx_sum = ({2'b0,smooth_x} << 1) + {2'b0,smooth_x} +
                         {2'b0,pupil_x} + 12'd2;
    wire [11:0] sy_sum = ({2'b0,smooth_y} << 1) + {2'b0,smooth_y} +
                         {2'b0,pupil_y} + 12'd2;
    wire [9:0] next_x = sx_sum[11:2];
    wire [9:0] next_y = sy_sum[11:2];
    wire signed [10:0] dx = $signed({1'b0,next_x}) - $signed({1'b0,anchor_x});
    wire signed [10:0] dy = $signed({1'b0,next_y}) - $signed({1'b0,anchor_y});
    wire x_negative = next_x < anchor_x;
    wire y_negative = next_y < anchor_y;
    wire [10:0] ax = x_negative ? ({1'b0,anchor_x} - {1'b0,next_x}) :
                                  ({1'b0,next_x} - {1'b0,anchor_x});
    wire [10:0] ay = y_negative ? ({1'b0,anchor_y} - {1'b0,next_y}) :
                                  ({1'b0,next_y} - {1'b0,anchor_y});
    wire move_enough = ax >= MOVE_THRESHOLD || ay >= MOVE_THRESHOLD;
    wire diagonal = ({1'b0,ax} <= ({1'b0,ay} << 1)) &&
                    ({1'b0,ay} <= ({1'b0,ax} << 1));
    wire [3:0] observed = diagonal ?
        (y_negative ? (x_negative ? 4'd5 : 4'd6) :
                      (x_negative ? 4'd7 : 4'd8)) :
        (ax > ay ? (x_negative ? 4'd1 : 4'd2) :
                   (y_negative ? 4'd3 : 4'd4));

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            anchored <= 1'b0;
            smooth_x <= 10'd0; smooth_y <= 10'd0;
            anchor_x <= 10'd0; anchor_y <= 10'd0;
            candidate <= 4'd0; candidate_count <= 2'd0;
            display_count <= 8'd0;
            motion_dir <= 4'd10; last_dir <= 4'd0;
            motion_dx <= 11'sd0; motion_dy <= 11'sd0;
        end else if (sample_valid) begin
            if (!eye_valid || no_eye || closed_eye) begin
                anchored <= 1'b0;
                candidate <= 4'd0;
                candidate_count <= 2'd0;
                display_count <= 8'd0;
                motion_dir <= closed_eye ? 4'd9 : 4'd10;
                motion_dx <= 11'sd0; motion_dy <= 11'sd0;
            end else if (!anchored) begin
                anchored <= 1'b1;
                smooth_x <= pupil_x; smooth_y <= pupil_y;
                anchor_x <= pupil_x; anchor_y <= pupil_y;
                candidate <= 4'd0;
                candidate_count <= 2'd0;
                display_count <= 8'd0;
                motion_dir <= 4'd0;
                motion_dx <= 11'sd0; motion_dy <= 11'sd0;
            end else begin
                smooth_x <= next_x; smooth_y <= next_y;
                motion_dx <= dx; motion_dy <= dy;
                if (display_count != 0) begin
                    display_count <= display_count - 1'b1;
                    if (display_count == 8'd1)
                        motion_dir <= 4'd0;
                end
                if (!move_enough) begin
                    candidate <= 4'd0;
                    candidate_count <= 2'd0;
                end else if (observed != candidate) begin
                    candidate <= observed;
                    candidate_count <= 2'd1;
                end else if (candidate_count == 2'd2) begin
                    motion_dir <= observed;
                    last_dir <= observed;
                    anchor_x <= next_x; anchor_y <= next_y;
                    candidate <= 4'd0;
                    candidate_count <= 2'd0;
                    display_count <= DISPLAY_SAMPLES;
                end else begin
                    candidate_count <= candidate_count + 1'b1;
                end
            end
        end
    end
endmodule
