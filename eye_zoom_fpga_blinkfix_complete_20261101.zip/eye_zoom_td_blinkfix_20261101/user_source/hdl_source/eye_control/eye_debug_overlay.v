// Generated eight-direction pupil-motion diagnostic overlay.
module eye_debug_overlay #(
    parameter ROI_X0=512, ROI_X1=1023, ROI_Y0=172, ROI_Y1=427
)(
    input wire clk, rst_n, in_vsync,
    input wire [9:0] pixel_x, pixel_y,
    input wire [23:0] in_rgb,
    input wire [9:0] pupil_x, pupil_y,
    input wire eye_valid, closed_eye, no_eye,
    input wire model_result_valid,
    input wire [2:0] model_class, selected_gaze,
    input wire tracking_result_valid,
    input wire [3:0] motion_dir, last_motion_dir,
    input wire signed [10:0] motion_dx, motion_dy,
    input wire [9:0] debug_width, debug_height,
    output wire [6:0] debug_input_addr,
    input wire [7:0] debug_input_gray,
    output reg [23:0] out_rgb
);
reg vsync_d, seen;
reg [7:0] missed;
reg [15:0] updates;
reg [2:0] view_class;
reg [3:0] view_motion, view_last_motion;
reg [9:0] view_x, view_y;
reg [9:0] view_width, view_height;
reg signed [10:0] view_dx, view_dy;
reg [1:0] view_eye, view_health;
reg [15:0] view_updates;
wire frame_start=in_vsync && !vsync_d;
always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        vsync_d<=0; seen<=0; missed<=0; updates<=0;
        view_class<=0; view_motion<=10; view_last_motion<=0;
        view_x<=0; view_y<=0; view_width<=0; view_height<=0;
        view_dx<=0; view_dy<=0;
        view_eye<=2; view_health<=0; view_updates<=0;
    end else begin
        vsync_d<=in_vsync;
        if(frame_start) begin
            if(missed<255) missed<=missed+1'b1;
            view_class<=model_class;
            view_motion<=closed_eye ? 4'd9 :
                         ((no_eye || !eye_valid) ? 4'd10 : motion_dir);
            view_last_motion<=(closed_eye || no_eye || !eye_valid) ? 4'd0 : last_motion_dir;
            view_x<=pupil_x; view_y<=pupil_y;
            view_width<=debug_width; view_height<=debug_height;
            view_dx<=motion_dx; view_dy<=motion_dy;
            view_eye<=closed_eye ? 2'd1 : ((no_eye || !eye_valid) ? 2'd2 : 2'd0);
            view_health<=!seen ? 2'd0 : (missed>=120 ? 2'd2 : 2'd1);
            view_updates<=updates;
        end
        if(tracking_result_valid) begin
            seen<=1; updates<=updates+1'b1; missed<=0;
        end
    end
end
function [5:0] dir_char;
input [2:0] code;
input [3:0] pos;
begin
dir_char=0;
case(code)
3'd0: case(pos)
4'd0: dir_char=6'd1;
4'd1: dir_char=6'd2;
endcase
3'd1: case(pos)
4'd0: dir_char=6'd3;
4'd1: dir_char=6'd4;
endcase
3'd2: case(pos)
4'd0: dir_char=6'd3;
4'd1: dir_char=6'd5;
endcase
3'd3: case(pos)
4'd0: dir_char=6'd3;
4'd1: dir_char=6'd6;
endcase
3'd4: case(pos)
4'd0: dir_char=6'd3;
4'd1: dir_char=6'd7;
endcase
3'd5: case(pos)
4'd0: dir_char=6'd8;
4'd1: dir_char=6'd9;
endcase
3'd6: case(pos)
4'd0: dir_char=6'd10;
4'd1: dir_char=6'd11;
endcase
3'd7: case(pos)
4'd0: dir_char=6'd10;
4'd1: dir_char=6'd11;
endcase
endcase
end
endfunction
function [5:0] motion_char;
input [3:0] code;
input [3:0] pos;
begin
motion_char=0;
case(code)
4'd0: case(pos)
4'd0: motion_char=6'd12;
4'd1: motion_char=6'd13;
endcase
4'd1: case(pos)
4'd0: motion_char=6'd3;
4'd1: motion_char=6'd4;
endcase
4'd2: case(pos)
4'd0: motion_char=6'd3;
4'd1: motion_char=6'd5;
endcase
4'd3: case(pos)
4'd0: motion_char=6'd3;
4'd1: motion_char=6'd6;
endcase
4'd4: case(pos)
4'd0: motion_char=6'd3;
4'd1: motion_char=6'd7;
endcase
4'd5: case(pos)
4'd0: motion_char=6'd4;
4'd1: motion_char=6'd6;
endcase
4'd6: case(pos)
4'd0: motion_char=6'd5;
4'd1: motion_char=6'd6;
endcase
4'd7: case(pos)
4'd0: motion_char=6'd4;
4'd1: motion_char=6'd7;
endcase
4'd8: case(pos)
4'd0: motion_char=6'd5;
4'd1: motion_char=6'd7;
endcase
4'd9: case(pos)
4'd0: motion_char=6'd8;
4'd1: motion_char=6'd9;
endcase
4'd10: case(pos)
4'd0: motion_char=6'd14;
4'd1: motion_char=6'd9;
endcase
endcase
end
endfunction
function [5:0] eye_char;
input [1:0] code;
input [3:0] pos;
begin
eye_char=0;
case(code)
2'd0: case(pos)
4'd0: eye_char=6'd15;
4'd1: eye_char=6'd16;
endcase
2'd1: case(pos)
4'd0: eye_char=6'd8;
4'd1: eye_char=6'd9;
endcase
2'd2: case(pos)
4'd0: eye_char=6'd14;
4'd1: eye_char=6'd9;
endcase
endcase
end
endfunction
function [5:0] health_char;
input [1:0] code;
input [3:0] pos;
begin
health_char=0;
case(code)
2'd0: case(pos)
4'd0: health_char=6'd17;
4'd1: health_char=6'd18;
endcase
2'd1: case(pos)
4'd0: health_char=6'd19;
4'd1: health_char=6'd20;
endcase
2'd2: case(pos)
4'd0: health_char=6'd21;
4'd1: health_char=6'd22;
endcase
endcase
end
endfunction
function [5:0] label_char;
input [2:0] code;
input [3:0] pos;
begin
label_char=0;
case(code)
3'd0: case(pos)
4'd0: label_char=6'd19;
4'd1: label_char=6'd23;
4'd2: label_char=6'd24;
4'd3: label_char=6'd3;
4'd4: label_char=6'd25;
endcase
3'd1: case(pos)
4'd0: label_char=6'd26;
4'd1: label_char=6'd27;
4'd2: label_char=6'd28;
4'd3: label_char=6'd29;
4'd4: label_char=6'd25;
endcase
3'd2: case(pos)
4'd0: label_char=6'd6;
4'd1: label_char=6'd30;
4'd2: label_char=6'd19;
4'd3: label_char=6'd23;
4'd4: label_char=6'd25;
endcase
3'd3: case(pos)
4'd0: label_char=6'd31;
4'd1: label_char=6'd32;
4'd2: label_char=6'd33;
4'd3: label_char=6'd34;
4'd4: label_char=6'd25;
endcase
3'd4: case(pos)
4'd0: label_char=6'd35;
4'd1: label_char=6'd36;
4'd2: label_char=6'd25;
endcase
3'd5: case(pos)
4'd0: label_char=6'd37;
4'd1: label_char=6'd38;
4'd2: label_char=6'd25;
endcase
3'd6: case(pos)
4'd0: label_char=6'd22;
4'd1: label_char=6'd39;
4'd2: label_char=6'd25;
endcase
3'd7: case(pos)
4'd0: label_char=6'd40;
4'd1: label_char=6'd41;
4'd2: label_char=6'd42;
4'd3: label_char=6'd43;
endcase
endcase
end
endfunction
function [5:0] hex_char;
input [3:0] code;
input [3:0] pos;
begin
hex_char=0;
case(code)
4'd0: case(pos)
4'd0: hex_char=6'd44;
endcase
4'd1: case(pos)
4'd0: hex_char=6'd45;
endcase
4'd2: case(pos)
4'd0: hex_char=6'd46;
endcase
4'd3: case(pos)
4'd0: hex_char=6'd47;
endcase
4'd4: case(pos)
4'd0: hex_char=6'd48;
endcase
4'd5: case(pos)
4'd0: hex_char=6'd49;
endcase
4'd6: case(pos)
4'd0: hex_char=6'd50;
endcase
4'd7: case(pos)
4'd0: hex_char=6'd51;
endcase
4'd8: case(pos)
4'd0: hex_char=6'd52;
endcase
4'd9: case(pos)
4'd0: hex_char=6'd53;
endcase
4'd10: case(pos)
4'd0: hex_char=6'd54;
endcase
4'd11: case(pos)
4'd0: hex_char=6'd55;
endcase
4'd12: case(pos)
4'd0: hex_char=6'd56;
endcase
4'd13: case(pos)
4'd0: hex_char=6'd57;
endcase
4'd14: case(pos)
4'd0: hex_char=6'd58;
endcase
4'd15: case(pos)
4'd0: hex_char=6'd59;
endcase
endcase
end
endfunction
function [15:0] font_row;
input [5:0] ch;
input [3:0] row;
begin
font_row=0;
case({ch,row})
10'd16: font_row=16'h0100;
10'd17: font_row=16'h0100;
10'd18: font_row=16'h0100;
10'd19: font_row=16'h7ffc;
10'd20: font_row=16'h610c;
10'd21: font_row=16'h610c;
10'd22: font_row=16'h610c;
10'd23: font_row=16'h610c;
10'd24: font_row=16'h610c;
10'd25: font_row=16'h7ffc;
10'd26: font_row=16'h610c;
10'd27: font_row=16'h0100;
10'd28: font_row=16'h0100;
10'd29: font_row=16'h0100;
10'd30: font_row=16'h0100;
10'd32: font_row=16'h2000;
10'd33: font_row=16'h37fc;
10'd34: font_row=16'h100c;
10'd35: font_row=16'h000c;
10'd36: font_row=16'h600c;
10'd37: font_row=16'h67cc;
10'd38: font_row=16'h644c;
10'd39: font_row=16'h644c;
10'd40: font_row=16'h67cc;
10'd41: font_row=16'h644c;
10'd42: font_row=16'h644c;
10'd43: font_row=16'h67cc;
10'd44: font_row=16'h600c;
10'd45: font_row=16'h600c;
10'd46: font_row=16'h6018;
10'd48: font_row=16'h0300;
10'd49: font_row=16'h0300;
10'd50: font_row=16'h0200;
10'd51: font_row=16'h7ffc;
10'd52: font_row=16'h600c;
10'd53: font_row=16'h600c;
10'd54: font_row=16'h6fec;
10'd55: font_row=16'h6c6c;
10'd56: font_row=16'h6c6c;
10'd57: font_row=16'h6c6c;
10'd58: font_row=16'h6fec;
10'd59: font_row=16'h6c0c;
10'd60: font_row=16'h600c;
10'd61: font_row=16'h600c;
10'd62: font_row=16'h6038;
10'd64: font_row=16'h0600;
10'd65: font_row=16'h0600;
10'd66: font_row=16'h0400;
10'd67: font_row=16'h7ffc;
10'd68: font_row=16'h0c00;
10'd69: font_row=16'h0c00;
10'd70: font_row=16'h0800;
10'd71: font_row=16'h1ffc;
10'd72: font_row=16'h18c0;
10'd73: font_row=16'h10c0;
10'd74: font_row=16'h30c0;
10'd75: font_row=16'h60c0;
10'd76: font_row=16'h40c0;
10'd77: font_row=16'h1ffc;
10'd80: font_row=16'h0200;
10'd81: font_row=16'h0200;
10'd82: font_row=16'h0600;
10'd83: font_row=16'h7ffc;
10'd84: font_row=16'h0400;
10'd85: font_row=16'h0c00;
10'd86: font_row=16'h0800;
10'd87: font_row=16'h1ff8;
10'd88: font_row=16'h3808;
10'd89: font_row=16'h6808;
10'd90: font_row=16'h4808;
10'd91: font_row=16'h0808;
10'd92: font_row=16'h0808;
10'd93: font_row=16'h0ff8;
10'd94: font_row=16'h0808;
10'd98: font_row=16'h0300;
10'd99: font_row=16'h0300;
10'd100: font_row=16'h0300;
10'd101: font_row=16'h0300;
10'd102: font_row=16'h03f8;
10'd103: font_row=16'h0300;
10'd104: font_row=16'h0300;
10'd105: font_row=16'h0300;
10'd106: font_row=16'h0300;
10'd107: font_row=16'h0300;
10'd108: font_row=16'h0300;
10'd109: font_row=16'h0300;
10'd110: font_row=16'h7ffc;
10'd113: font_row=16'h7ffc;
10'd114: font_row=16'h0300;
10'd115: font_row=16'h0300;
10'd116: font_row=16'h0300;
10'd117: font_row=16'h0380;
10'd118: font_row=16'h03e0;
10'd119: font_row=16'h0330;
10'd120: font_row=16'h0318;
10'd121: font_row=16'h0300;
10'd122: font_row=16'h0300;
10'd123: font_row=16'h0300;
10'd124: font_row=16'h0300;
10'd125: font_row=16'h0300;
10'd126: font_row=16'h0100;
10'd128: font_row=16'h2000;
10'd129: font_row=16'h37fc;
10'd130: font_row=16'h100c;
10'd131: font_row=16'h00cc;
10'd132: font_row=16'h60cc;
10'd133: font_row=16'h6ffc;
10'd134: font_row=16'h61cc;
10'd135: font_row=16'h61cc;
10'd136: font_row=16'h62cc;
10'd137: font_row=16'h6ecc;
10'd138: font_row=16'h78cc;
10'd139: font_row=16'h60cc;
10'd140: font_row=16'h638c;
10'd141: font_row=16'h600c;
10'd142: font_row=16'h4018;
10'd145: font_row=16'h7bf8;
10'd146: font_row=16'h4b08;
10'd147: font_row=16'h4b08;
10'd148: font_row=16'h7bf8;
10'd149: font_row=16'h4b08;
10'd150: font_row=16'h4b08;
10'd151: font_row=16'h4bf8;
10'd152: font_row=16'h7b40;
10'd153: font_row=16'h4b2c;
10'd154: font_row=16'h4b38;
10'd155: font_row=16'h7b30;
10'd156: font_row=16'h4318;
10'd157: font_row=16'h43cc;
10'd158: font_row=16'h0304;
10'd160: font_row=16'h0100;
10'd161: font_row=16'h0100;
10'd162: font_row=16'h0100;
10'd163: font_row=16'h3ff8;
10'd164: font_row=16'h0100;
10'd165: font_row=16'h0100;
10'd166: font_row=16'h0100;
10'd167: font_row=16'h7ffc;
10'd168: font_row=16'h0380;
10'd169: font_row=16'h07c0;
10'd170: font_row=16'h0d60;
10'd171: font_row=16'h1930;
10'd172: font_row=16'h711c;
10'd173: font_row=16'h4104;
10'd174: font_row=16'h0100;
10'd176: font_row=16'h2000;
10'd177: font_row=16'h2000;
10'd178: font_row=16'h3efc;
10'd179: font_row=16'h688c;
10'd180: font_row=16'h488c;
10'd181: font_row=16'h488c;
10'd182: font_row=16'h088c;
10'd183: font_row=16'h7f8c;
10'd184: font_row=16'h088c;
10'd185: font_row=16'h188c;
10'd186: font_row=16'h1c8c;
10'd187: font_row=16'h168c;
10'd188: font_row=16'h23fc;
10'd189: font_row=16'h608c;
10'd190: font_row=16'h4000;
10'd192: font_row=16'h1840;
10'd193: font_row=16'h7e40;
10'd194: font_row=16'h18f8;
10'd195: font_row=16'h7f90;
10'd196: font_row=16'h19fc;
10'd197: font_row=16'h7e2c;
10'd198: font_row=16'h002c;
10'd199: font_row=16'h7ffe;
10'd200: font_row=16'h662c;
10'd201: font_row=16'h7e2c;
10'd202: font_row=16'h66fc;
10'd203: font_row=16'h7e20;
10'd204: font_row=16'h6620;
10'd205: font_row=16'h6620;
10'd206: font_row=16'h6ce0;
10'd209: font_row=16'h0080;
10'd210: font_row=16'h0180;
10'd211: font_row=16'h0180;
10'd212: font_row=16'h0180;
10'd213: font_row=16'h1180;
10'd214: font_row=16'h1180;
10'd215: font_row=16'h11fc;
10'd216: font_row=16'h1180;
10'd217: font_row=16'h1180;
10'd218: font_row=16'h1180;
10'd219: font_row=16'h1180;
10'd220: font_row=16'h1180;
10'd221: font_row=16'h1180;
10'd222: font_row=16'h7ffc;
10'd225: font_row=16'h3ff8;
10'd226: font_row=16'h0300;
10'd227: font_row=16'h0300;
10'd228: font_row=16'h0300;
10'd229: font_row=16'h0300;
10'd230: font_row=16'h7ffc;
10'd231: font_row=16'h0380;
10'd232: font_row=16'h0280;
10'd233: font_row=16'h0680;
10'd234: font_row=16'h0480;
10'd235: font_row=16'h0c84;
10'd236: font_row=16'h3884;
10'd237: font_row=16'h60fc;
10'd238: font_row=16'h4000;
10'd240: font_row=16'h0200;
10'd241: font_row=16'h0600;
10'd242: font_row=16'h7ffc;
10'd243: font_row=16'h0c00;
10'd244: font_row=16'h0800;
10'd245: font_row=16'h1ff0;
10'd246: font_row=16'h1810;
10'd247: font_row=16'h3810;
10'd248: font_row=16'h6ff0;
10'd249: font_row=16'h4810;
10'd250: font_row=16'h0810;
10'd251: font_row=16'h0ff0;
10'd252: font_row=16'h0810;
10'd253: font_row=16'h0810;
10'd254: font_row=16'h0870;
10'd256: font_row=16'h1020;
10'd257: font_row=16'h1860;
10'd258: font_row=16'h0840;
10'd259: font_row=16'h7f7c;
10'd260: font_row=16'h04c8;
10'd261: font_row=16'h26c8;
10'd262: font_row=16'h63c8;
10'd263: font_row=16'h45d8;
10'd264: font_row=16'h3c70;
10'd265: font_row=16'h1830;
10'd266: font_row=16'h1c30;
10'd267: font_row=16'h1470;
10'd268: font_row=16'h3258;
10'd269: font_row=16'h618c;
10'd270: font_row=16'h0104;
10'd272: font_row=16'h1000;
10'd273: font_row=16'h30c0;
10'd274: font_row=16'h3ffc;
10'd275: font_row=16'h6920;
10'd276: font_row=16'h4100;
10'd277: font_row=16'h3ff8;
10'd278: font_row=16'h0100;
10'd279: font_row=16'h7ffc;
10'd280: font_row=16'h0020;
10'd281: font_row=16'h0020;
10'd282: font_row=16'h7ffc;
10'd283: font_row=16'h0820;
10'd284: font_row=16'h0c20;
10'd285: font_row=16'h0620;
10'd286: font_row=16'h00e0;
10'd288: font_row=16'h1840;
10'd289: font_row=16'h1040;
10'd290: font_row=16'h63fc;
10'd291: font_row=16'h4840;
10'd292: font_row=16'h1840;
10'd293: font_row=16'h17fc;
10'd294: font_row=16'h3010;
10'd295: font_row=16'h7010;
10'd296: font_row=16'h57fc;
10'd297: font_row=16'h1010;
10'd298: font_row=16'h1310;
10'd299: font_row=16'h1110;
10'd300: font_row=16'h1190;
10'd301: font_row=16'h1010;
10'd302: font_row=16'h1070;
10'd305: font_row=16'h63f8;
10'd306: font_row=16'h3000;
10'd307: font_row=16'h1000;
10'd309: font_row=16'h07fc;
10'd310: font_row=16'h7180;
10'd311: font_row=16'h11b0;
10'd312: font_row=16'h1110;
10'd313: font_row=16'h1318;
10'd314: font_row=16'h17f8;
10'd315: font_row=16'h17cc;
10'd316: font_row=16'h3000;
10'd317: font_row=16'h7c00;
10'd318: font_row=16'h47fc;
10'd320: font_row=16'h0800;
10'd321: font_row=16'h13fc;
10'd322: font_row=16'h3000;
10'd323: font_row=16'h6000;
10'd324: font_row=16'h4c00;
10'd325: font_row=16'h1800;
10'd326: font_row=16'h13fc;
10'd327: font_row=16'h3010;
10'd328: font_row=16'h7010;
10'd329: font_row=16'h5010;
10'd330: font_row=16'h1010;
10'd331: font_row=16'h1010;
10'd332: font_row=16'h1010;
10'd333: font_row=16'h1010;
10'd334: font_row=16'h10f0;
10'd336: font_row=16'h0840;
10'd337: font_row=16'h1ffc;
10'd338: font_row=16'h1000;
10'd339: font_row=16'h33f8;
10'd340: font_row=16'h3208;
10'd341: font_row=16'h7208;
10'd342: font_row=16'h73f8;
10'd343: font_row=16'h7000;
10'd344: font_row=16'h37fc;
10'd345: font_row=16'h3404;
10'd346: font_row=16'h33f8;
10'd347: font_row=16'h3040;
10'd348: font_row=16'h3040;
10'd349: font_row=16'h3040;
10'd350: font_row=16'h31c0;
10'd352: font_row=16'h7ffc;
10'd353: font_row=16'h0100;
10'd354: font_row=16'h3ff8;
10'd355: font_row=16'h3108;
10'd356: font_row=16'h3108;
10'd357: font_row=16'h3ff8;
10'd358: font_row=16'h3108;
10'd359: font_row=16'h3108;
10'd360: font_row=16'h3ff8;
10'd361: font_row=16'h1300;
10'd362: font_row=16'h0b00;
10'd363: font_row=16'h0e00;
10'd364: font_row=16'h1fc0;
10'd365: font_row=16'h70fc;
10'd369: font_row=16'h0020;
10'd370: font_row=16'h7e20;
10'd371: font_row=16'h0020;
10'd372: font_row=16'h01fc;
10'd373: font_row=16'h7f24;
10'd374: font_row=16'h1064;
10'd375: font_row=16'h3064;
10'd376: font_row=16'h3664;
10'd377: font_row=16'h2244;
10'd378: font_row=16'h2244;
10'd379: font_row=16'h7fc4;
10'd380: font_row=16'h718c;
10'd381: font_row=16'h018c;
10'd382: font_row=16'h0138;
10'd384: font_row=16'h0100;
10'd385: font_row=16'h0100;
10'd386: font_row=16'h0180;
10'd387: font_row=16'h7ffc;
10'd388: font_row=16'h0400;
10'd389: font_row=16'h0400;
10'd390: font_row=16'h0400;
10'd391: font_row=16'h07f8;
10'd392: font_row=16'h0c18;
10'd393: font_row=16'h0c10;
10'd394: font_row=16'h0810;
10'd395: font_row=16'h1810;
10'd396: font_row=16'h1010;
10'd397: font_row=16'h3030;
10'd398: font_row=16'h61e0;
10'd403: font_row=16'h1800;
10'd404: font_row=16'h1800;
10'd410: font_row=16'h1800;
10'd411: font_row=16'h1800;
10'd416: font_row=16'h0840;
10'd417: font_row=16'h18c0;
10'd418: font_row=16'h17fc;
10'd419: font_row=16'h3080;
10'd420: font_row=16'h3180;
10'd421: font_row=16'h7ffc;
10'd422: font_row=16'hf100;
10'd423: font_row=16'h3100;
10'd424: font_row=16'h33f8;
10'd425: font_row=16'h3018;
10'd426: font_row=16'h3030;
10'd427: font_row=16'h31e0;
10'd428: font_row=16'h30e0;
10'd429: font_row=16'h3060;
10'd430: font_row=16'h3000;
10'd432: font_row=16'h1040;
10'd433: font_row=16'h1860;
10'd434: font_row=16'h1060;
10'd435: font_row=16'h33fc;
10'd436: font_row=16'h2cc0;
10'd437: font_row=16'h7898;
10'd438: font_row=16'h79b8;
10'd439: font_row=16'h33fc;
10'd440: font_row=16'h29b0;
10'd441: font_row=16'h79b0;
10'd442: font_row=16'h01b0;
10'd443: font_row=16'h1d34;
10'd444: font_row=16'h7334;
10'd445: font_row=16'h061c;
10'd448: font_row=16'h1040;
10'd449: font_row=16'h10e0;
10'd450: font_row=16'h10b0;
10'd451: font_row=16'h7918;
10'd452: font_row=16'h330c;
10'd453: font_row=16'h35f4;
10'd454: font_row=16'h3800;
10'd455: font_row=16'h3848;
10'd456: font_row=16'h7248;
10'd457: font_row=16'h5348;
10'd458: font_row=16'h5158;
10'd459: font_row=16'h1110;
10'd460: font_row=16'h1030;
10'd461: font_row=16'h17fc;
10'd462: font_row=16'h1000;
10'd464: font_row=16'h0004;
10'd465: font_row=16'h37c4;
10'd466: font_row=16'h1c54;
10'd467: font_row=16'h0554;
10'd468: font_row=16'h0554;
10'd469: font_row=16'h6554;
10'd470: font_row=16'h3554;
10'd471: font_row=16'h0554;
10'd472: font_row=16'h0554;
10'd473: font_row=16'h1554;
10'd474: font_row=16'h3754;
10'd475: font_row=16'h2204;
10'd476: font_row=16'h2384;
10'd477: font_row=16'h64c4;
10'd478: font_row=16'h485c;
10'd480: font_row=16'h0100;
10'd481: font_row=16'h4300;
10'd482: font_row=16'h7300;
10'd483: font_row=16'h13fc;
10'd484: font_row=16'h060c;
10'd485: font_row=16'h06c8;
10'd486: font_row=16'h0cc8;
10'd487: font_row=16'h00c0;
10'd488: font_row=16'h18c0;
10'd489: font_row=16'h30e0;
10'd490: font_row=16'h21a0;
10'd491: font_row=16'h6130;
10'd492: font_row=16'h4318;
10'd493: font_row=16'h0e0c;
10'd494: font_row=16'h0804;
10'd496: font_row=16'h1090;
10'd497: font_row=16'h1190;
10'd498: font_row=16'h17fc;
10'd499: font_row=16'h3090;
10'd500: font_row=16'h7bf8;
10'd501: font_row=16'h3208;
10'd502: font_row=16'h3bf8;
10'd503: font_row=16'h3a08;
10'd504: font_row=16'h73f8;
10'd505: font_row=16'h7040;
10'd506: font_row=16'h57fc;
10'd507: font_row=16'h10e0;
10'd508: font_row=16'h1190;
10'd509: font_row=16'h171c;
10'd510: font_row=16'h1404;
10'd512: font_row=16'h0008;
10'd513: font_row=16'h7f68;
10'd514: font_row=16'h1268;
10'd515: font_row=16'h1268;
10'd516: font_row=16'h7fe8;
10'd517: font_row=16'h1268;
10'd518: font_row=16'h3208;
10'd519: font_row=16'h6208;
10'd520: font_row=16'h4138;
10'd521: font_row=16'h0100;
10'd522: font_row=16'h3ff8;
10'd523: font_row=16'h0100;
10'd524: font_row=16'h0100;
10'd525: font_row=16'h7ffc;
10'd528: font_row=16'h0800;
10'd529: font_row=16'h490c;
10'd530: font_row=16'h296c;
10'd531: font_row=16'h2b6c;
10'd532: font_row=16'h0a6c;
10'd533: font_row=16'h7f6c;
10'd534: font_row=16'h0c6c;
10'd535: font_row=16'h086c;
10'd536: font_row=16'h086c;
10'd537: font_row=16'h7fec;
10'd538: font_row=16'h086c;
10'd539: font_row=16'h180c;
10'd540: font_row=16'h100c;
10'd541: font_row=16'h300c;
10'd542: font_row=16'h6038;
10'd544: font_row=16'h0404;
10'd545: font_row=16'h443c;
10'd546: font_row=16'h55e0;
10'd547: font_row=16'h56c0;
10'd548: font_row=16'h46c0;
10'd549: font_row=16'h7fc0;
10'd550: font_row=16'h4cfc;
10'd551: font_row=16'h4ec8;
10'd552: font_row=16'h5fc8;
10'd553: font_row=16'h74c8;
10'd554: font_row=16'h6488;
10'd555: font_row=16'h4488;
10'd556: font_row=16'h7f88;
10'd557: font_row=16'h0188;
10'd558: font_row=16'h0008;
10'd560: font_row=16'h0100;
10'd561: font_row=16'h1910;
10'd562: font_row=16'h1930;
10'd563: font_row=16'h1130;
10'd564: font_row=16'h3930;
10'd565: font_row=16'h2d78;
10'd566: font_row=16'h65cc;
10'd567: font_row=16'h4184;
10'd568: font_row=16'h0100;
10'd569: font_row=16'h3ff8;
10'd570: font_row=16'h0100;
10'd571: font_row=16'h0100;
10'd572: font_row=16'h0100;
10'd573: font_row=16'h7ffc;
10'd576: font_row=16'h1000;
10'd577: font_row=16'h11fc;
10'd578: font_row=16'h1000;
10'd579: font_row=16'h1000;
10'd580: font_row=16'h7c00;
10'd581: font_row=16'h1000;
10'd582: font_row=16'h3bfc;
10'd583: font_row=16'h3c60;
10'd584: font_row=16'h3460;
10'd585: font_row=16'h5168;
10'd586: font_row=16'hd168;
10'd587: font_row=16'h1364;
10'd588: font_row=16'h1264;
10'd589: font_row=16'h1064;
10'd590: font_row=16'h10c0;
10'd592: font_row=16'h0840;
10'd593: font_row=16'h0840;
10'd594: font_row=16'h1840;
10'd595: font_row=16'h17fc;
10'd596: font_row=16'h3000;
10'd597: font_row=16'h7118;
10'd598: font_row=16'h7118;
10'd599: font_row=16'h1110;
10'd600: font_row=16'h1110;
10'd601: font_row=16'h1110;
10'd602: font_row=16'h1190;
10'd603: font_row=16'h11b0;
10'd604: font_row=16'h1020;
10'd605: font_row=16'h17fc;
10'd606: font_row=16'h1000;
10'd608: font_row=16'h0040;
10'd609: font_row=16'h3c40;
10'd610: font_row=16'h70f8;
10'd611: font_row=16'h1318;
10'd612: font_row=16'h12f0;
10'd613: font_row=16'h7c60;
10'd614: font_row=16'h33a0;
10'd615: font_row=16'h387c;
10'd616: font_row=16'h34cc;
10'd617: font_row=16'h5388;
10'd618: font_row=16'h5278;
10'd619: font_row=16'h1030;
10'd620: font_row=16'h1060;
10'd621: font_row=16'h1380;
10'd622: font_row=16'h1200;
10'd624: font_row=16'h1000;
10'd625: font_row=16'h087c;
10'd626: font_row=16'h7fe0;
10'd627: font_row=16'h2680;
10'd628: font_row=16'h2480;
10'd629: font_row=16'h7f80;
10'd630: font_row=16'h08fc;
10'd631: font_row=16'h0898;
10'd632: font_row=16'h7f98;
10'd633: font_row=16'h0898;
10'd634: font_row=16'h2a98;
10'd635: font_row=16'h4a98;
10'd636: font_row=16'h4998;
10'd637: font_row=16'h1918;
10'd638: font_row=16'h0108;
10'd640: font_row=16'h7ffc;
10'd641: font_row=16'h600c;
10'd642: font_row=16'h622c;
10'd643: font_row=16'h722c;
10'd644: font_row=16'h7fac;
10'd645: font_row=16'h6eec;
10'd646: font_row=16'h646c;
10'd647: font_row=16'h666c;
10'd648: font_row=16'h6e6c;
10'd649: font_row=16'h6bbc;
10'd650: font_row=16'h799c;
10'd651: font_row=16'h710c;
10'd652: font_row=16'h600c;
10'd653: font_row=16'h6038;
10'd656: font_row=16'h0080;
10'd657: font_row=16'h1080;
10'd658: font_row=16'h31fc;
10'd659: font_row=16'h2188;
10'd660: font_row=16'h2f98;
10'd661: font_row=16'h7a70;
10'd662: font_row=16'h7870;
10'd663: font_row=16'h11d8;
10'd664: font_row=16'h270c;
10'd665: font_row=16'h79f8;
10'd666: font_row=16'h4108;
10'd667: font_row=16'h0108;
10'd668: font_row=16'h3d08;
10'd669: font_row=16'h61f8;
10'd670: font_row=16'h0108;
10'd672: font_row=16'h2060;
10'd673: font_row=16'h3060;
10'd674: font_row=16'h7cb0;
10'd675: font_row=16'h230c;
10'd676: font_row=16'h27fc;
10'd677: font_row=16'h7000;
10'd678: font_row=16'h53d4;
10'd679: font_row=16'h7e54;
10'd680: font_row=16'h13d4;
10'd681: font_row=16'h1254;
10'd682: font_row=16'h1e54;
10'd683: font_row=16'h7bd4;
10'd684: font_row=16'h1244;
10'd685: font_row=16'h1244;
10'd686: font_row=16'h12dc;
10'd689: font_row=16'h0400;
10'd690: font_row=16'h0600;
10'd691: font_row=16'h0300;
10'd692: font_row=16'h0100;
10'd693: font_row=16'h0380;
10'd694: font_row=16'h0380;
10'd695: font_row=16'h02c0;
10'd696: font_row=16'h0660;
10'd697: font_row=16'h0460;
10'd698: font_row=16'h0c30;
10'd699: font_row=16'h1818;
10'd700: font_row=16'h300c;
10'd701: font_row=16'h6004;
10'd706: font_row=16'h03c0;
10'd707: font_row=16'h0260;
10'd708: font_row=16'h0620;
10'd709: font_row=16'h0420;
10'd710: font_row=16'h0430;
10'd711: font_row=16'h0430;
10'd712: font_row=16'h0430;
10'd713: font_row=16'h0420;
10'd714: font_row=16'h0620;
10'd715: font_row=16'h0260;
10'd716: font_row=16'h03c0;
10'd722: font_row=16'h0180;
10'd723: font_row=16'h0380;
10'd724: font_row=16'h0080;
10'd725: font_row=16'h0080;
10'd726: font_row=16'h0080;
10'd727: font_row=16'h0080;
10'd728: font_row=16'h0080;
10'd729: font_row=16'h0080;
10'd730: font_row=16'h0080;
10'd731: font_row=16'h0080;
10'd732: font_row=16'h07e0;
10'd738: font_row=16'h03c0;
10'd739: font_row=16'h0660;
10'd740: font_row=16'h0060;
10'd741: font_row=16'h0060;
10'd742: font_row=16'h0060;
10'd743: font_row=16'h0040;
10'd744: font_row=16'h00c0;
10'd745: font_row=16'h0180;
10'd746: font_row=16'h0300;
10'd747: font_row=16'h0600;
10'd748: font_row=16'h07f0;
10'd754: font_row=16'h03c0;
10'd755: font_row=16'h0660;
10'd756: font_row=16'h0020;
10'd757: font_row=16'h0060;
10'd758: font_row=16'h00e0;
10'd759: font_row=16'h01c0;
10'd760: font_row=16'h0060;
10'd761: font_row=16'h0020;
10'd762: font_row=16'h0030;
10'd763: font_row=16'h0660;
10'd764: font_row=16'h03c0;
10'd770: font_row=16'h00c0;
10'd771: font_row=16'h00c0;
10'd772: font_row=16'h01c0;
10'd773: font_row=16'h0340;
10'd774: font_row=16'h0240;
10'd775: font_row=16'h0640;
10'd776: font_row=16'h0460;
10'd777: font_row=16'h0ff0;
10'd778: font_row=16'h0040;
10'd779: font_row=16'h0040;
10'd780: font_row=16'h0040;
10'd786: font_row=16'h07e0;
10'd787: font_row=16'h0600;
10'd788: font_row=16'h0600;
10'd789: font_row=16'h0600;
10'd790: font_row=16'h07c0;
10'd791: font_row=16'h0060;
10'd792: font_row=16'h0020;
10'd793: font_row=16'h0030;
10'd794: font_row=16'h0020;
10'd795: font_row=16'h0660;
10'd796: font_row=16'h03c0;
10'd802: font_row=16'h01e0;
10'd803: font_row=16'h0320;
10'd804: font_row=16'h0600;
10'd805: font_row=16'h0400;
10'd806: font_row=16'h05c0;
10'd807: font_row=16'h0660;
10'd808: font_row=16'h0430;
10'd809: font_row=16'h0430;
10'd810: font_row=16'h0630;
10'd811: font_row=16'h0360;
10'd812: font_row=16'h01c0;
10'd818: font_row=16'h07f0;
10'd819: font_row=16'h0020;
10'd820: font_row=16'h0060;
10'd821: font_row=16'h0040;
10'd822: font_row=16'h00c0;
10'd823: font_row=16'h0080;
10'd824: font_row=16'h0180;
10'd825: font_row=16'h0180;
10'd826: font_row=16'h0180;
10'd827: font_row=16'h0180;
10'd828: font_row=16'h0180;
10'd834: font_row=16'h03c0;
10'd835: font_row=16'h0660;
10'd836: font_row=16'h0620;
10'd837: font_row=16'h0620;
10'd838: font_row=16'h0360;
10'd839: font_row=16'h03c0;
10'd840: font_row=16'h0660;
10'd841: font_row=16'h0430;
10'd842: font_row=16'h0430;
10'd843: font_row=16'h0660;
10'd844: font_row=16'h03c0;
10'd850: font_row=16'h03c0;
10'd851: font_row=16'h0660;
10'd852: font_row=16'h0420;
10'd853: font_row=16'h0420;
10'd854: font_row=16'h0430;
10'd855: font_row=16'h0670;
10'd856: font_row=16'h03a0;
10'd857: font_row=16'h0020;
10'd858: font_row=16'h0060;
10'd859: font_row=16'h04c0;
10'd860: font_row=16'h0380;
10'd866: font_row=16'h0380;
10'd867: font_row=16'h0380;
10'd868: font_row=16'h0280;
10'd869: font_row=16'h06c0;
10'd870: font_row=16'h06c0;
10'd871: font_row=16'h0440;
10'd872: font_row=16'h0c60;
10'd873: font_row=16'h0fe0;
10'd874: font_row=16'h0820;
10'd875: font_row=16'h1830;
10'd876: font_row=16'h1830;
10'd882: font_row=16'h0fc0;
10'd883: font_row=16'h0c60;
10'd884: font_row=16'h0c30;
10'd885: font_row=16'h0c20;
10'd886: font_row=16'h0c60;
10'd887: font_row=16'h0fc0;
10'd888: font_row=16'h0c30;
10'd889: font_row=16'h0c10;
10'd890: font_row=16'h0c10;
10'd891: font_row=16'h0c70;
10'd892: font_row=16'h0fe0;
10'd898: font_row=16'h03e0;
10'd899: font_row=16'h0770;
10'd900: font_row=16'h0400;
10'd901: font_row=16'h0c00;
10'd902: font_row=16'h0c00;
10'd903: font_row=16'h0800;
10'd904: font_row=16'h0c00;
10'd905: font_row=16'h0c00;
10'd906: font_row=16'h0c00;
10'd907: font_row=16'h0770;
10'd908: font_row=16'h03e0;
10'd914: font_row=16'h0fc0;
10'd915: font_row=16'h0ce0;
10'd916: font_row=16'h0c30;
10'd917: font_row=16'h0c10;
10'd918: font_row=16'h0c10;
10'd919: font_row=16'h0c18;
10'd920: font_row=16'h0c10;
10'd921: font_row=16'h0c10;
10'd922: font_row=16'h0c30;
10'd923: font_row=16'h0c60;
10'd924: font_row=16'h0fc0;
10'd930: font_row=16'h0fe0;
10'd931: font_row=16'h0c00;
10'd932: font_row=16'h0c00;
10'd933: font_row=16'h0c00;
10'd934: font_row=16'h0c00;
10'd935: font_row=16'h0fc0;
10'd936: font_row=16'h0c00;
10'd937: font_row=16'h0c00;
10'd938: font_row=16'h0c00;
10'd939: font_row=16'h0c00;
10'd940: font_row=16'h0fe0;
10'd946: font_row=16'h07f0;
10'd947: font_row=16'h0600;
10'd948: font_row=16'h0600;
10'd949: font_row=16'h0600;
10'd950: font_row=16'h0600;
10'd951: font_row=16'h07e0;
10'd952: font_row=16'h0600;
10'd953: font_row=16'h0600;
10'd954: font_row=16'h0600;
10'd955: font_row=16'h0600;
10'd956: font_row=16'h0600;
10'd962: font_row=16'h0860;
10'd963: font_row=16'h0c40;
10'd964: font_row=16'h04c0;
10'd965: font_row=16'h0680;
10'd966: font_row=16'h0380;
10'd967: font_row=16'h0300;
10'd968: font_row=16'h0380;
10'd969: font_row=16'h0680;
10'd970: font_row=16'h04c0;
10'd971: font_row=16'h0c60;
10'd972: font_row=16'h1860;
10'd978: font_row=16'h0c30;
10'd979: font_row=16'h0420;
10'd980: font_row=16'h0660;
10'd981: font_row=16'h0240;
10'd982: font_row=16'h03c0;
10'd983: font_row=16'h0180;
10'd984: font_row=16'h0180;
10'd985: font_row=16'h0180;
10'd986: font_row=16'h0180;
10'd987: font_row=16'h0180;
10'd988: font_row=16'h0180;
10'd996: font_row=16'h0180;
10'd997: font_row=16'h0180;
10'd998: font_row=16'h0180;
10'd999: font_row=16'h0ff0;
10'd1000: font_row=16'h0180;
10'd1001: font_row=16'h0180;
10'd1002: font_row=16'h0180;
10'd1013: font_row=16'h03c0;
endcase
end
endfunction
wire in_panel=pixel_x>=8 && pixel_x<496 && pixel_y>=8 && pixel_y<248;
wire in_text=pixel_x>=16 && pixel_x<496 && pixel_y>=16 && pixel_y<240;
wire in_caption=pixel_x>=16 && pixel_x<144 && pixel_y>=232 && pixel_y<264;
wire in_preview=pixel_x>=16 && pixel_x<272 && pixel_y>=272 && pixel_y<400;
wire [9:0] tx=pixel_x-16, ty=pixel_y-16, cy=pixel_y-232;
wire [3:0] col=tx[8:5];
wire [2:0] line=ty[7:5];
wire [9:0] py=pixel_y-272;
assign debug_input_addr={py[6:4],tx[7:4]};
reg [5:0] ch;
reg [3:0] digit;
reg [10:0] magnitude;
reg [15:0] row_bits;
always @* begin
    ch=0; digit=0; magnitude=0;
    if(in_text) begin
        case(line)
        0: if(col<5) ch=label_char(0,col); else ch=motion_char(view_motion,col-5);
        1: if(col<5) ch=label_char(1,col); else ch=eye_char(view_eye,col-5);
        2: if(col<5) ch=label_char(2,col); else ch=motion_char(view_last_motion,col-5);
        3: if(col<5) ch=label_char(3,col); else ch=dir_char(view_class,col-5);
        4: begin
            if(col<3) ch=label_char(4,col);
            else if(col==3) ch=6'd60;
            else if(col>=4 && col<=6) begin
                case(col)
                    4: digit={2'b0,view_x[9:8]};
                    5: digit=view_x[7:4];
                    6: digit=view_x[3:0];
                endcase
                ch=hex_char(digit,0);
            end else if(col==8) ch=6'd61;
            else if(col>=9 && col<=11) begin
                case(col)
                    9: digit={2'b0,view_y[9:8]};
                    10: digit=view_y[7:4];
                    11: digit=view_y[3:0];
                endcase
                ch=hex_char(digit,0);
            end
        end
        5: begin
            if(col<3) ch=label_char(5,col);
            else if(col==3) ch=6'd60;
            else if(col==4) ch=view_dx<0 ? 6'd63 : 6'd62;
            else if(col>=5 && col<=7) begin
                magnitude=view_dx<0 ? -view_dx : view_dx;
                case(col)
                    5: digit={1'b0,magnitude[10:8]};
                    6: digit=magnitude[7:4];
                    7: digit=magnitude[3:0];
                endcase
                ch=hex_char(digit,0);
            end else if(col==9) ch=6'd61;
            else if(col==10) ch=view_dy<0 ? 6'd63 : 6'd62;
            else if(col>=11 && col<=13) begin
                magnitude=view_dy<0 ? -view_dy : view_dy;
                case(col)
                    11: digit={1'b0,magnitude[10:8]};
                    12: digit=magnitude[7:4];
                    13: digit=magnitude[3:0];
                endcase
                ch=hex_char(digit,0);
            end
        end
        6: begin
            if(col<3) ch=label_char(6,col);
            else if(col<7) begin
                case(col)
                    3: digit=view_updates[15:12];
                    4: digit=view_updates[11:8];
                    5: digit=view_updates[7:4];
                    6: digit=view_updates[3:0];
                endcase
                ch=hex_char(digit,0);
            end else if(col==8) ch=6'd60; // X = detected dark-box width
            else if(col>=9 && col<=11) begin
                case(col)
                    9: digit={2'b0,view_width[9:8]};
                    10: digit=view_width[7:4];
                    11: digit=view_width[3:0];
                endcase
                ch=hex_char(digit,0);
            end else if(col==12) ch=6'd61; // Y = dark-box height
            else if(col>=13 && col<=14) begin
                digit=(col==13) ? view_height[7:4] : view_height[3:0];
                ch=hex_char(digit,0);
            end
        end
        endcase
    end else if(in_caption) ch=label_char(7,col);
    row_bits=font_row(ch,in_caption ? cy[4:1] : ty[4:1]);
end
wire on_roi=(((pixel_y==ROI_Y0 || pixel_y==ROI_Y1) && pixel_x>=ROI_X0 && pixel_x<=ROI_X1) ||
             ((pixel_x==ROI_X0 || pixel_x==ROI_X1) && pixel_y>=ROI_Y0 && pixel_y<=ROI_Y1));
wire on_cross=eye_valid && (((pixel_x==pupil_x) && ({1'b0,pixel_y}+11'd8>={1'b0,pupil_y}) && ({1'b0,pixel_y}<={1'b0,pupil_y}+11'd8)) ||
                          ((pixel_y==pupil_y) && ({1'b0,pixel_x}+11'd8>={1'b0,pupil_x}) && ({1'b0,pixel_x}<={1'b0,pupil_x}+11'd8)));
always @* begin
    out_rgb=in_rgb;
    if(on_roi) out_rgb=24'h00ff00;
    if(on_cross) out_rgb=24'hff00ff;
    if(in_panel || in_caption) out_rgb=24'h101820;
    if((in_text || in_caption) && row_bits[15-tx[4:1]]) begin
        out_rgb=24'hffffff;
        if(in_text && line==0) out_rgb=24'hffff00;
        if(in_text && line==1 && view_eye!=0) out_rgb=24'hff8080;
    end
    if(in_preview) out_rgb=seen ? {debug_input_gray,debug_input_gray,debug_input_gray} : 24'h000000;
end
endmodule
