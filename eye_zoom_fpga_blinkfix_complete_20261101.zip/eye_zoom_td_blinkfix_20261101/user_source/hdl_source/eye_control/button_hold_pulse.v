// Synchronizes an active-low push button and emits one pulse after it has
// remained pressed for HOLD_CYCLES. It will not pulse again until released.
module button_hold_pulse #(
    parameter HOLD_CYCLES = 1000000,
    parameter COUNTER_WIDTH = 20
) (
    input  wire clk,
    input  wire rst_n,
    input  wire button_n,
    output reg  pressed_pulse
);
    reg sync_1;
    reg sync_2;
    reg armed;
    reg [COUNTER_WIDTH-1:0] hold_count;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            sync_1       <= 1'b1;
            sync_2       <= 1'b1;
            armed        <= 1'b1;
            hold_count   <= {COUNTER_WIDTH{1'b0}};
            pressed_pulse <= 1'b0;
        end else begin
            sync_1 <= button_n;
            sync_2 <= sync_1;
            pressed_pulse <= 1'b0;
            if (sync_2) begin
                hold_count <= {COUNTER_WIDTH{1'b0}};
                armed <= 1'b1;
            end else if (armed) begin
                if (hold_count == HOLD_CYCLES - 1) begin
                    pressed_pulse <= 1'b1;
                    armed <= 1'b0;
                end else begin
                    hold_count <= hold_count + 1'b1;
                end
            end
        end
    end
endmodule
