"""Build a self-contained Chinese status overlay and a visual layout check."""
from pathlib import Path
import argparse
from PIL import Image, ImageDraw, ImageFont

parser = argparse.ArgumentParser()
parser.add_argument('project', type=Path)
args = parser.parse_args()
font = ImageFont.truetype(r'C:\Windows\Fonts\Noto Sans SC (TrueType).otf', 15)
directions = ['中间','向左','向右','向上','向下','闭眼','未知','未知']
motions = ['静止','向左','向右','向上','向下','左上','右上','左下','右下','闭眼','无眼']
eyes = ['有效','闭眼','无眼']
health = ['等待','运行','停更']
labels = ['运动方向：','传统检测：','上次运动：','模型判断：','坐标：','位移：','更新：','网络输入']
chars = list(dict.fromkeys(''.join(directions+motions+eyes+health+labels)+'0123456789ABCDEFXY+-'))
ids = {ch:i+1 for i,ch in enumerate(chars)}
glyphs = {}
for ch in chars:
    im = Image.new('L',(16,16)); d=ImageDraw.Draw(im)
    b=d.textbbox((0,0),ch,font=font)
    d.text(((16-b[2]+b[0])//2-b[0],(16-b[3]+b[1])//2-b[1]),ch,font=font,fill=255)
    glyphs[ch]=[sum((im.getpixel((x,y))>=96)<<(15-x) for x in range(16)) for y in range(16)]

def string_fn(name, strings, bits):
    s=[f'function [5:0] {name};', f'input [{bits-1}:0] code;', 'input [3:0] pos;', 'begin', f'{name}=0;', 'case(code)']
    for i,t in enumerate(strings):
        s += [f"{bits}'d{i}: case(pos)"] + [f"4'd{j}: {name}=6'd{ids[c]};" for j,c in enumerate(t)] + ['endcase']
    return '\n'.join(s+['endcase','end','endfunction'])

rtl = '''// Generated eight-direction pupil-motion diagnostic overlay.
module eye_debug_overlay #(
    parameter ROI_X0=512, ROI_X1=1023, ROI_Y0=172, ROI_Y1=427
)(
    input wire clk, rst_n, in_vsync,
    input wire [9:0] pixel_x, pixel_y,
    input wire [23:0] in_rgb,
    input wire [9:0] pupil_x, pupil_y,
    input wire eye_valid, closed_eye, no_eye,
    input wire model_result_valid,
    input wire [2:0] model_class, selected_gaze,
    input wire tracking_result_valid,
    input wire [3:0] motion_dir, last_motion_dir,
    input wire signed [10:0] motion_dx, motion_dy,
    output wire [6:0] debug_input_addr,
    input wire [7:0] debug_input_gray,
    output reg [23:0] out_rgb
);
reg vsync_d, seen;
reg [7:0] missed;
reg [15:0] updates;
reg [2:0] view_class;
reg [3:0] view_motion, view_last_motion;
reg [9:0] view_x, view_y;
reg signed [10:0] view_dx, view_dy;
reg [1:0] view_eye, view_health;
reg [15:0] view_updates;
wire frame_start=in_vsync && !vsync_d;
always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        vsync_d<=0; seen<=0; missed<=0; updates<=0;
        view_class<=0; view_motion<=10; view_last_motion<=0;
        view_x<=0; view_y<=0; view_dx<=0; view_dy<=0;
        view_eye<=2; view_health<=0; view_updates<=0;
    end else begin
        vsync_d<=in_vsync;
        if(frame_start) begin
            if(missed<255) missed<=missed+1'b1;
            view_class<=model_class;
            view_motion<=motion_dir; view_last_motion<=last_motion_dir;
            view_x<=pupil_x; view_y<=pupil_y;
            view_dx<=motion_dx; view_dy<=motion_dy;
            view_eye<=closed_eye ? 2'd1 : ((no_eye || !eye_valid) ? 2'd2 : 2'd0);
            view_health<=!seen ? 2'd0 : (missed>=120 ? 2'd2 : 2'd1);
            view_updates<=updates;
        end
        if(tracking_result_valid) begin
            seen<=1; updates<=updates+1'b1; missed<=0;
        end
    end
end
'''
rtl += string_fn('dir_char',directions,3)+'\n'+string_fn('motion_char',motions,4)+'\n'+string_fn('eye_char',eyes,2)+'\n'+string_fn('health_char',health,2)+'\n'+string_fn('label_char',labels,3)+'\n'+string_fn('hex_char',list('0123456789ABCDEF'),4)+'\n'
rtl += '''function [15:0] font_row;
input [5:0] ch;
input [3:0] row;
begin
font_row=0;
case({ch,row})
'''
for ch,rows in glyphs.items():
    for y,v in enumerate(rows):
        if v: rtl += f"10'd{ids[ch]*16+y}: font_row=16'h{v:04x};\n"
rtl += '''endcase
end
endfunction
wire in_panel=pixel_x>=8 && pixel_x<496 && pixel_y>=8 && pixel_y<248;
wire in_text=pixel_x>=16 && pixel_x<496 && pixel_y>=16 && pixel_y<240;
wire in_caption=pixel_x>=16 && pixel_x<144 && pixel_y>=232 && pixel_y<264;
wire in_preview=pixel_x>=16 && pixel_x<272 && pixel_y>=272 && pixel_y<400;
wire [9:0] tx=pixel_x-16, ty=pixel_y-16, cy=pixel_y-232;
wire [3:0] col=tx[8:5];
wire [2:0] line=ty[7:5];
wire [9:0] py=pixel_y-272;
assign debug_input_addr={py[6:4],tx[7:4]};
reg [5:0] ch;
reg [3:0] digit;
reg [10:0] magnitude;
reg [15:0] row_bits;
always @* begin
    ch=0; digit=0; magnitude=0;
    if(in_text) begin
        case(line)
        0: if(col<5) ch=label_char(0,col); else ch=motion_char(view_motion,col-5);
        1: if(col<5) ch=label_char(1,col); else ch=eye_char(view_eye,col-5);
        2: if(col<5) ch=label_char(2,col); else ch=motion_char(view_last_motion,col-5);
        3: if(col<5) ch=label_char(3,col); else ch=dir_char(view_class,col-5);
        4: begin
            if(col<3) ch=label_char(4,col);
            else if(col==3) ch=6'd''' + str(ids['X']) + ''';
            else if(col>=4 && col<=6) begin
                case(col)
                    4: digit={2'b0,view_x[9:8]};
                    5: digit=view_x[7:4];
                    6: digit=view_x[3:0];
                endcase
                ch=hex_char(digit,0);
            end else if(col==8) ch=6'd''' + str(ids['Y']) + ''';
            else if(col>=9 && col<=11) begin
                case(col)
                    9: digit={2'b0,view_y[9:8]};
                    10: digit=view_y[7:4];
                    11: digit=view_y[3:0];
                endcase
                ch=hex_char(digit,0);
            end
        end
        5: begin
            if(col<3) ch=label_char(5,col);
            else if(col==3) ch=6'd''' + str(ids['X']) + ''';
            else if(col==4) ch=view_dx<0 ? 6'd''' + str(ids['-']) + ''' : 6'd''' + str(ids['+']) + ''';
            else if(col>=5 && col<=7) begin
                magnitude=view_dx<0 ? -view_dx : view_dx;
                case(col)
                    5: digit={1'b0,magnitude[10:8]};
                    6: digit=magnitude[7:4];
                    7: digit=magnitude[3:0];
                endcase
                ch=hex_char(digit,0);
            end else if(col==9) ch=6'd''' + str(ids['Y']) + ''';
            else if(col==10) ch=view_dy<0 ? 6'd''' + str(ids['-']) + ''' : 6'd''' + str(ids['+']) + ''';
            else if(col>=11 && col<=13) begin
                magnitude=view_dy<0 ? -view_dy : view_dy;
                case(col)
                    11: digit={1'b0,magnitude[10:8]};
                    12: digit=magnitude[7:4];
                    13: digit=magnitude[3:0];
                endcase
                ch=hex_char(digit,0);
            end
        end
        6: begin
            if(col<3) ch=label_char(6,col);
            else if(col<7) begin
                case(col)
                    3: digit=view_updates[15:12];
                    4: digit=view_updates[11:8];
                    5: digit=view_updates[7:4];
                    6: digit=view_updates[3:0];
                endcase
                ch=hex_char(digit,0);
            end else if(col>=8) ch=health_char(view_health,col-8);
        end
        endcase
    end else if(in_caption) ch=label_char(7,col);
    row_bits=font_row(ch,in_caption ? cy[4:1] : ty[4:1]);
end
wire on_roi=(((pixel_y==ROI_Y0 || pixel_y==ROI_Y1) && pixel_x>=ROI_X0 && pixel_x<=ROI_X1) ||
             ((pixel_x==ROI_X0 || pixel_x==ROI_X1) && pixel_y>=ROI_Y0 && pixel_y<=ROI_Y1));
wire on_cross=eye_valid && (((pixel_x==pupil_x) && ({1'b0,pixel_y}+11'd8>={1'b0,pupil_y}) && ({1'b0,pixel_y}<={1'b0,pupil_y}+11'd8)) ||
                          ((pixel_y==pupil_y) && ({1'b0,pixel_x}+11'd8>={1'b0,pupil_x}) && ({1'b0,pixel_x}<={1'b0,pupil_x}+11'd8)));
always @* begin
    out_rgb=in_rgb;
    if(on_roi) out_rgb=24'h00ff00;
    if(on_cross) out_rgb=24'hff00ff;
    if(in_panel || in_caption) out_rgb=24'h101820;
    if((in_text || in_caption) && row_bits[15-tx[4:1]]) begin
        out_rgb=24'hffffff;
        if(in_text && line==0) out_rgb=24'hffff00;
        if(in_text && line==1 && view_eye!=0) out_rgb=24'hff8080;
    end
    if(in_preview) out_rgb=seen ? {debug_input_gray,debug_input_gray,debug_input_gray} : 24'h000000;
end
endmodule
'''
out=args.project/'user_source/hdl_source/eye_control/eye_debug_overlay.v'
out.write_text(rtl,encoding='ascii')
# Layout inspection from the same glyph bitmap. No camera images are needed.
preview=Image.new('RGB',(1024,600),(70,80,90)); draw=ImageDraw.Draw(preview)
draw.rectangle((512,172,1023,427),outline=(0,255,0),width=2)
draw.rectangle((8,8,495,151),fill=(16,24,32))
draw.rectangle((8,8,495,247),fill=(16,24,32))
for row,t in enumerate(['运动方向：左上','传统检测：有效','上次运动：向右','模型判断：向下','坐标：X2A0 Y13C','位移：X+00A Y-005','更新：01A2 运行']):
    for j,c in enumerate(t):
        if c==' ':continue
        for y,v in enumerate(glyphs[c]):
            for x in range(16):
                if v&(1<<(15-x)):draw.rectangle((16+j*32+x*2,16+row*32+y*2,17+j*32+x*2,17+row*32+y*2),fill='yellow' if row==0 else 'white')
preview.save(args.project/'debug_layout.png')
print(out)
