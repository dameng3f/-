"""Package the verified FPGA project and compare the released bit with the build."""
from hashlib import sha256
from pathlib import Path
from shutil import copy2
from zipfile import ZipFile, ZIP_DEFLATED
import re

root = Path(__file__).resolve().parents[1]
release = root.parents[1] / "release" / "eye_zoom_fpga_blinkfix_20261101"
release.mkdir(parents=True, exist_ok=True)

project = root / "td_project" / "camera_to_dsi_display.al"
refs = re.findall(r'<File Path="([^"]+)"', project.read_text(encoding="utf-8"))
missing = [path for path in refs if not (project.parent / path).resolve().exists()]
if missing:
    raise SystemExit("Missing project sources: " + ", ".join(missing[:8]))

bit = root / "eye_zoom_blinkfix.bit"
expected = "0bc24c5978eb4c6028086832b33d34f1965dd3deb75deaddac35ffdcc222667c"
actual = sha256(bit.read_bytes()).hexdigest()
if actual != expected:
    raise SystemExit(f"Bit hash mismatch: {actual}")

archive = release / "eye_zoom_fpga_blinkfix_complete_20261101.zip"
with ZipFile(archive, "w", ZIP_DEFLATED, compresslevel=6) as z:
    for file in root.rglob("*"):
        if file.is_file() and "__pycache__" not in file.parts:
            z.write(file, Path(root.name) / file.relative_to(root))
with ZipFile(archive) as z:
    if z.testzip() is not None:
        raise SystemExit("Archive CRC test failed")
    packed = z.read(f"{root.name}/eye_zoom_blinkfix.bit")
    if sha256(packed).hexdigest() != actual:
        raise SystemExit("Packed bit differs from original")

for name in ("eye_zoom_blinkfix.bit", "README_CN.md", "BUILD_RESULT.md",
             "preview_1x.png", "preview_2x.png"):
    copy2(root / name, release / name)
print(f"OK: {len(refs)} project file references; bit SHA256 {actual}")
print(archive)
