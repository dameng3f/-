"""Rasterize the editable Chinese article into 16x16 FPGA font/page ROMs."""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "assets" / "reading_text.txt"
OUT = ROOT / "user_source" / "hdl_source" / "eye_control"
FONT = Path(r"C:\Windows\Fonts\Noto Sans SC (TrueType).otf")
COLS, ROWS = 64, 34

article = "".join(line.strip() for line in SRC.read_text(encoding="utf-8").splitlines())
if not article:
    raise SystemExit("Reading text is empty")
header = "安路眼动阅读倍率方向眼睛步数到边界无有效闭左 右上下中X0123456789ABCDEF"
chars = sorted(set(article + header))
glyph = {char: index + 1 for index, char in enumerate(chars)}
if len(glyph) > 254:
    raise SystemExit(f"Too many glyphs: {len(glyph)} > 254")

page = []
cursor = 0
for row in range(ROWS):
    for col in range(COLS):
        if col in (0, 63):
            page.append(0)
        else:
            page.append(glyph[article[cursor % len(article)]])
            cursor += 1
(OUT / "reader_page.mem").write_text("\n".join(f"{x:02x}" for x in page) + "\n", encoding="ascii")

font = ImageFont.truetype(str(FONT), 15)
rows = [0] * (256 * 16)
for char, index in glyph.items():
    im = Image.new("1", (16, 16), 0)
    draw = ImageDraw.Draw(im)
    box = draw.textbbox((0, 0), char, font=font)
    draw.text(((16 - (box[2] - box[0])) // 2 - box[0],
               (16 - (box[3] - box[1])) // 2 - box[1]), char, font=font, fill=1)
    for y in range(16):
        rows[index * 16 + y] = sum((1 << (15 - x)) for x in range(16) if im.getpixel((x, y)))
(OUT / "reader_font.mem").write_text("\n".join(f"{x:04x}" for x in rows) + "\n", encoding="ascii")

# This function is included in reader_page.v via a generated Verilog header.
lines = ["function [7:0] reader_char_id;", "input [15:0] code;", "begin", "case(code)"]
for char, index in glyph.items():
    lines.append(f"16'h{ord(char):04x}: reader_char_id=8'd{index};")
lines += ["default: reader_char_id=8'd0;", "endcase", "end", "endfunction"]
(OUT / "reader_char_ids.vh").write_text("\n".join(lines) + "\n", encoding="ascii")
print(f"Generated {len(page)} page cells and {len(glyph)} glyphs")
