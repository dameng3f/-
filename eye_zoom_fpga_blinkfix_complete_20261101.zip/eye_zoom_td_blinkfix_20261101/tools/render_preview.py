"""Render the generated FPGA page/font ROMs for visual inspection on a PC."""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parents[1]
ROM = ROOT / "user_source" / "hdl_source" / "eye_control"
page = [int(x, 16) for x in (ROM / "reader_page.mem").read_text().split()]
font = [int(x, 16) for x in (ROM / "reader_font.mem").read_text().split()]
if len(page) != 64 * 34 or len(font) != 256 * 16:
    raise SystemExit("ROM length mismatch")

for zoom in (False, True):
    image = Image.new("RGB", (1024, 600), "#fffdf6")
    pixels = image.load()
    pan_x, pan_y = 256, 128
    for y in range(56, 600):
        source_y = pan_y + (y - 56) // 2 if zoom else y - 56
        for x in range(1024):
            source_x = pan_x + x // 2 if zoom else x
            index = page[(source_y // 16) * 64 + source_x // 16]
            ink = font[index * 16 + source_y % 16] & (1 << (15 - source_x % 16))
            if ink:
                pixels[x, y] = (23, 38, 55)
    draw = ImageDraw.Draw(image)
    draw.rectangle((0, 0, 1023, 55), fill="#183b68")
    header_font = ImageFont.truetype(r"C:\Windows\Fonts\Noto Sans SC (TrueType).otf", 17)
    draw.text((16, 16), f"安路眼动阅读   倍率 {'2X' if zoom else '1X'}   方向 中   眼睛 有   步数 0000", font=header_font, fill="white")
    draw.rectangle((992, 16, 1015, 39), fill="#41d185")
    if not zoom:
        draw.rectangle((pan_x, 56 + pan_y, pan_x + 511, 56 + pan_y + 271), outline="#1673e0", width=2)
    out = ROOT / ("preview_2x.png" if zoom else "preview_1x.png")
    image.save(out)
    print(out)
